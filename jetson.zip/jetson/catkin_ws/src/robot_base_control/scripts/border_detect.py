#!/usr/bin/env python3

import rospy
import numpy as np
from sensor_msgs.msg import Image
from std_msgs.msg import String, Int32
from geometry_msgs.msg import Twist  # Para controlar o movimento do robô

class TableEdgeDetector:
    def __init__(self):
        rospy.init_node('table_edge_detector', anonymous=True)

        # Variável para armazenar a direção desejada
        self.search_direction = None
        
        # Subscritor para iniciar a detecção ao receber uma mensagem
        self.edge_detect_sub = rospy.Subscriber("/edge_detect", String, self.edge_detect_callback)

        # Subscritor de imagem de profundidade
        self.depth_sub = rospy.Subscriber("/camera/depth/image_rect_raw", Image, self.depth_callback)

        # Publisher de movimento do robô
        self.cmd_vel_pub = rospy.Publisher("/cmd_vel", Twist, queue_size=10)

        # Publisher de feedback de detecção
        self.edge_feedback_pub = rospy.Publisher("/edge_detect/feedback", Int32, queue_size=10)
        
        # Variáveis de controle
        self.twist = Twist()
        self.edge_detected = False
        self.recent_distances = []
        self.movement_active = False

        rospy.loginfo("TableEdgeDetector iniciado, aguardando comando de detecção...")

    def edge_detect_callback(self, msg):
        if "start" in msg.data:
            command = msg.data.split(",")
            if len(command) == 2:
                direction = command[1].strip()
                if direction in ["esquerda", "direita"]:
                    self.search_direction = direction
                    self.movement_active = True
                    self.edge_detected = False
                    self.recent_distances = []
                    rospy.loginfo(f"Comando de detecção de borda recebido: {direction}")

    def depth_callback(self, data):
        if not self.movement_active or self.edge_detected:
            return

        try:
            height, width = data.height, data.width
            depth_array = np.frombuffer(data.data, dtype=np.uint16).reshape(height, width)

            # Configuração da ROI com base na direção
            center_x = 100 if self.search_direction == "esquerda" else width - 100
            center_y = height // 2
            roi_size = 20
            roi_x_start = max(0, center_x - roi_size // 2)
            roi_x_end = min(width, center_x + roi_size // 2)
            roi_y_start = max(0, center_y - roi_size // 2)
            roi_y_end = min(height, center_y + roi_size // 2)

            roi_depth_data = depth_array[roi_y_start:roi_y_end, roi_x_start:roi_x_end]
            mean_distance = np.mean(roi_depth_data) / 1000.0

            rospy.loginfo(f"Distância média da ROI: {mean_distance:.2f} metros")

            self.recent_distances.append(mean_distance)
            if len(self.recent_distances) > 6:
                self.recent_distances.pop(0)

            valid_readings = sum(1 for d in self.recent_distances if d > 0.3)
            rospy.loginfo(f"Leituras válidas consecutivas: {valid_readings}")
            
            if valid_readings >= 6:
                rospy.loginfo("Borda da mesa detectada! Parando o robô.")
                self.stop_robot()
                self.edge_detected = True
                self.movement_active = False
                for i in range(5):
                    self.edge_feedback_pub.publish(1)
                    rospy.sleep(0.1)
            else:
                self.move_robot()

        except Exception as e:
            rospy.logerr(f"Erro ao processar a imagem de profundidade: {e}")
            self.edge_feedback_pub.publish(0)

    def move_robot(self):
        self.twist.linear.x = 0.0
        if self.search_direction == "direita":
            self.twist.angular.z = -0.35  # Rotação para a direita
            rospy.loginfo("Movendo para a direita...")
        elif self.search_direction == "esquerda":
            self.twist.angular.z = 0.35  # Rotação para a esquerda
            rospy.loginfo("Movendo para a esquerda...")
        self.cmd_vel_pub.publish(self.twist)

    def stop_robot(self):
        self.twist.linear.x = 0.0
        self.twist.angular.z = 0.0
        self.cmd_vel_pub.publish(self.twist)
        rospy.loginfo("Robô parado.")

if __name__ == '__main__':
    try:
        detector = TableEdgeDetector()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass

