#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
from std_msgs.msg import String, Int32, Float32

class MoveToTarget:
    def __init__(self):
        rospy.init_node('move_to_target', anonymous=True)
        self.ultrasound_sub = rospy.Subscriber("/ultrasound_sensor_front", Float32, self.ultrasound_callback)
        self.start_sub = rospy.Subscriber("/align_table", String, self.start_callback)
        self.vel_pub = rospy.Publisher("/cmd_vel", Twist, queue_size=10)
        self.feedback_pub = rospy.Publisher("/align_table/feedback", Int32, queue_size=10)
        self.twist = Twist()
        self.start_movement = False
        self.target_distance = None
        self.recent_distances = []

    def start_callback(self, msg):
        try:
            command, distance_str = msg.data.split(',')
            if command.strip() == "start":
                self.target_distance = float(distance_str.strip())
                rospy.loginfo(f"Comando para iniciar o movimento recebido! Distância alvo: {self.target_distance:.2f} metros")
                self.start_movement = True
        except ValueError:
            rospy.logwarn("Formato do comando inválido. Use: 'start, <distância>'")

    def ultrasound_callback(self, data):
        if not self.start_movement or self.target_distance is None:
            return

        center_distance = data.data / 100
        rospy.loginfo("Distância do sensor ultrassônico: %.2f metros" % center_distance)

        self.recent_distances.append(center_distance)
        if len(self.recent_distances) > 3:
            self.recent_distances.pop(0)

        if center_distance < self.target_distance - 0.02:
            rospy.loginfo(f"Distância menor que a meta de {self.target_distance:.2f} metros. Movendo para trás...")
            self.twist.linear.x = -0.2
        elif center_distance > self.target_distance + 0.02:
            rospy.loginfo(f"Distância maior que a meta de {self.target_distance:.2f} metros. Movendo para frente...")
            self.twist.linear.x = 0.2
        else:
            self.twist.linear.x = 0.0
            self.twist.angular.z = 0.0
            rospy.loginfo(f"Alinhamento concluído na distância alvo de {self.target_distance:.2f} metros!")

            for i in range(5):
                self.feedback_pub.publish(1)
                rospy.sleep(0.1)

            self.start_movement = False
            self.vel_pub.publish(self.twist)
            
            return 

        self.vel_pub.publish(self.twist)

if __name__ == '__main__':
    try:
        move_to_target = MoveToTarget()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
