#!/usr/bin/env python

import rospy
from std_msgs.msg import String, Int32, Float32
from sensor_msgs.msg import Range
from apriltag_ros.msg import AprilTagDetectionArray

class ZigZagSearch:
    def __init__(self):
        rospy.init_node('search_block')

        self.aruco_reference_id = None
        self.distance_threshold = 0.10  # 15 cm
        self.center_tolerance = 0.06  # Tolerância de 10% em relação ao centro da imagem

        self.pub_move_time = rospy.Publisher('/move_time', String, queue_size=10)
        self.pub_feedback = rospy.Publisher('/search_block/feedback', Int32, queue_size=10)
        self.pub_found_block = rospy.Publisher('/found_block', Int32, queue_size=10)
        
        self.sub_search = rospy.Subscriber('/search_block', String, self.search_callback)
        self.sub_tag_detections = rospy.Subscriber('/tag_detections', AprilTagDetectionArray, self.tag_detection_callback)
        self.sub_ultrasound_right = rospy.Subscriber('/ultrasound_sensor_right', Float32, self.ultrasound_callback)

        self.rate = rospy.Rate(50)
        self.movement_active = False
        self.search_any_block = False  # Novo indicador para buscar qualquer bloco
        self.target_found = False
        self.current_distance = float('inf')  # Inicializa com um valor alto

    def search_callback(self, msg):
        try:
            command, block_id = msg.data.split(',')
            block_id = int(block_id.strip())

            if command == 'start':
                self.aruco_reference_id = block_id
                self.search_any_block = (block_id == -1)
                self.movement_active = True
                self.target_found = False
                rospy.loginfo("Movimento zigue-zague iniciado.")
                self.perform_zigzag()
            else:
                rospy.logwarn(f"Comando desconhecido: {command}")
        
        except ValueError as e:
            rospy.logerr(f"Erro ao interpretar a mensagem: {msg.data}. Formato esperado: 'start, <ID_do_bloco>'")

    def ultrasound_callback(self, data):
        self.current_distance = data.data / 100  # Atualiza a distância com a leitura do sensor ultrassônico

    def perform_zigzag(self):
        rospy.sleep(2)
        while self.current_distance > self.distance_threshold and self.movement_active:
            rospy.loginfo("Executando movimento de zigue-zague...")
                
            if not self.movement_active:
                return

            rospy.loginfo("Movendo para a direita por 2.0 segundos.")
            self.pub_move_time.publish("direita,2")
            rospy.sleep(2.6)
            
            if not self.movement_active:
                return

            rospy.loginfo("Movendo para trás por 1.1 segundos.")
            self.pub_move_time.publish("tras,1.1")
            rospy.sleep(1.4)

            if not self.movement_active:
                return

            rospy.loginfo("Movendo para a direita por 2.0 segundos.")
            self.pub_move_time.publish("direita,2")
            rospy.sleep(2.6)

            if not self.movement_active:
                return

            rospy.loginfo("Movendo para a frente por 1.1 segundos.")
            self.pub_move_time.publish("frente,1.1")
            rospy.sleep(1.4)

            if not self.movement_active:
                return

    def tag_detection_callback(self, data):
        if not self.movement_active or self.target_found:
            return

        for detection in data.detections:
            tag_id = detection.id[0]
            if self.search_any_block or tag_id == self.aruco_reference_id:
                # Calcula a posição do bloco em relação ao centro da imagem
                center_x = detection.pose.pose.pose.position.x
                center_y = detection.pose.pose.pose.position.y
                if abs(center_x) < self.center_tolerance and abs(center_y) < self.center_tolerance:
                    rospy.loginfo(f"Bloco detectado no centro com ID {tag_id}.")
                    self.pub_found_block.publish(tag_id)
                    self.target_found = True
                    self.stop_movement(immediate=True)
                else:
                    rospy.loginfo(f"Bloco detectado fora do centro com ID {tag_id}. Coordenadas: ({center_x}, {center_y})")

    def perform_reverse_zigzag(self):
        try:
            rospy.loginfo("Executando movimento de zigue-zague reverso...")

            for cycle in range(3):
                rospy.loginfo(f"Executando ciclo inverso {cycle + 1}/3")

                if not self.movement_active:
                    return

                rospy.loginfo("Movendo para a esquerda por 2.0 segundos.")
                self.pub_move_time.publish("esquerda,2.0")
                rospy.sleep(2.3)

                if not self.movement_active:
                    return

                rospy.loginfo("Movendo para trás por 1.1 segundos.")
                self.pub_move_time.publish("tras,1.1")
                rospy.sleep(1.4)

                if not self.movement_active:
                    return

                rospy.loginfo("Movendo para a esquerda por 2.0 segundos.")
                self.pub_move_time.publish("esquerda,2.0")
                rospy.sleep(2.3)

                if not self.movement_active:
                    return

                rospy.loginfo("Movendo para a frente por 1.1 segundos.")
                self.pub_move_time.publish("frente,1.1")
                rospy.sleep(1.4)

                if cycle < 2:
                    rospy.loginfo("Movendo para a esquerda por 2.0 segundos.")
                    self.pub_move_time.publish("esquerda,2.0")
                    rospy.sleep(2.3)

            rospy.loginfo("Movimento de zigue-zague reverso completo.")
            if self.movement_active:
                self.pub_feedback.publish(1)

        except Exception as e:
            rospy.logerr("Erro durante o movimento inverso: %s", str(e))
            self.pub_feedback.publish(0)
            self.movement_active = False

    def stop_movement(self, immediate=False):
        if self.movement_active or immediate:
            rospy.loginfo("Parando o movimento.")
            self.pub_move_time.publish("parar,0")
            if self.movement_active:
                for b in range(5):
                    self.pub_feedback.publish(1)
                    rospy.sleep(0.1)
            self.movement_active = False

    def run(self):
        while not rospy.is_shutdown():
            self.rate.sleep()

if __name__ == '__main__':
    try:
        zigzag = ZigZagSearch()
        zigzag.run()
    except rospy.ROSInterruptException:
        pass