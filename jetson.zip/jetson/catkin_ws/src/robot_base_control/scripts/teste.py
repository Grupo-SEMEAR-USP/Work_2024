#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from datetime import datetime

class CmdVelLogger:
    def __init__(self):
        rospy.init_node('cmd_vel_logger', anonymous=True)

        # Nome do arquivo para armazenar os logs
        self.log_file = "./cmd_vel_publishers_log.txt"

        # Abre o arquivo de log no modo append
        with open(self.log_file, 'a') as f:
            f.write("\n--- Iniciando registro de nós que publicam no /cmd_vel ---\n")

        # Assinatura no tópico /cmd_vel
        self.subscriber = rospy.Subscriber('/cmd_vel', Twist, self.cmd_vel_callback)

        rospy.loginfo("Logger de publicadores do /cmd_vel inicializado. Monitorando publicações no tópico...")

    def cmd_vel_callback(self, msg):
        # Obtém o nome do nó publicador
        caller_id = rospy.get_caller_id()
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Log da publicação
        log_entry = f"[{timestamp}] - Publicador: {caller_id}\n"

        # Adiciona ao arquivo de log
        with open(self.log_file, 'a') as f:
            f.write(log_entry)

        rospy.loginfo(f"Registrado: {log_entry.strip()}")

    def run(self):
        rospy.spin()

if __name__ == '__main__':
    try:
        logger = CmdVelLogger()
        logger.run()
    except rospy.ROSInterruptException:
        pass
