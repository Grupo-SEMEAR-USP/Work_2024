#!/usr/bin/env python3

import rospy
import smach
import smach_ros
import time
from std_msgs.msg import Int32, String, Float32
import subprocess
from robot_arm_control.msg import MoveToPoseCommand

interest_block = None # Id do bloco de interesse
counter = 0 # Contador dos blocos pegos
block_color = None # Cor do bloco atual

area_de_interesse = None

active_task = None 

color = ["nada", "nada", "red", "blue", "red", "blue"]
ids = [1, 18, 7, 6, 15, 13]

# Stacking 1, stacking 2, container red 1, container blue 1, container red 2, container blue 2 

containers = [6, 13, 7, 15]
stack = [1, 18]

class Task1(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/gripper_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK1':
            return
        rospy.loginfo(f"Feedback recebido Task1: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 1: Publicar "start" no tópico /gripper_angle')
        active_task = 'TASK1'

        time.sleep(1.5)

        self.pub_gripper.publish(0.0)
        self.pub_gripper.publish(0.0)
        self.pub_gripper.publish(0.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/gripper_angle/feedback', Float32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(10)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task2(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/align_table', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK2':
            return
        rospy.loginfo(f"Feedback recebido Task2: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('\nExecuting Task 2: Publicar "start,0.15" no tópico /align_table')
        active_task = 'TASK2'

        self.pub_align.publish("start,0.15")
        self.pub_align.publish("start,0.15")
        self.pub_align.publish("start,0.15")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/align_table/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(15)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'
    
class Task3(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/edge_detect', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK3':
            return
        rospy.loginfo(f"Feedback recebido Task3: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('\nExecuting Task 3: Publicar "alinha a borda da mesa" no tópico /edge_detect')
        active_task = 'TASK3'

        time.sleep(1)

        self.pub_align.publish("start,esquerda")

        self.feedback_received = None

        self.subscriber = rospy.Subscriber('/edge_detect/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(10)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task4(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/search_block', String, queue_size=10)
        self.feedback_received = None
        self.found_block_id = None
        self.subscriber = None
        self.found_block_subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK4':
            return
        rospy.loginfo(f"Feedback recebido Task4: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, interest_block, ids, counter

        interest_block = ids[counter]

        rospy.loginfo(f"\nExecuting Task 4: Procurando o bloco {interest_block}")

        time.sleep(1)
        active_task = 'TASK4'

        self.pub_align.publish("start," + str(interest_block))
        
        rospy.loginfo(f"Publicando busca para o bloco: {interest_block}")

        self.feedback_received = None
        self.found_block_id = None
        self.subscriber = rospy.Subscriber('/search_block/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(40)
        while self.feedback_received not in [0, 1] and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task5(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/block_align', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK5':
            return
        rospy.loginfo(f"Feedback recebido Task5: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, interest_block, ids, counter

        rospy.loginfo(f"\nExecuting Task 5: Alinhando ao bloco {interest_block}")

        time.sleep(1.5)
        active_task = 'TASK5'

        self.pub_align.publish(f"{interest_block}")
        rospy.loginfo(f"Publicando alinhar com o bloco: {interest_block}")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/block_align/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(30)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'
        
class Task6(smach.State):

    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        
    def execute(self, userdata):
        global active_task, block_color
        rospy.loginfo("\nExecuting Task 6: Aguardando detecção da cor do bloco")

        time.sleep(1)
        active_task = 'TASK6'

        rospy.loginfo(f"Cor: {color[counter]}")

        block_color = color[counter]

        return 'completed'
    
class Task7(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/move_time', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK7':
            return
        rospy.loginfo(f"Feedback recebido Task7: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo(f"\nExecuting Task 7: Andando para frente")

        time.sleep(1)
        active_task = 'TASK7'

        self.pub_align.publish("frente,0.4")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/move_time/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(5)
        while self.feedback_received not in [0, 1] and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task8(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/manipulator_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK8':
            return
        rospy.loginfo(f"Feedback recebido Task8: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('\nExecuting Task 8: Publicar "-11400.0" no tópico /manipulator_angle')
        active_task = 'TASK8'

        time.sleep(1.5)

        self.pub_gripper.publish(-11400.0)
        self.pub_gripper.publish(-11400.0)
        self.pub_gripper.publish(-11400.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/manipulator_angle/feedback', Float32, self.feedback_cb)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        time.sleep(8)

        return 'completed'

class Task9(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/gripper_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK9':
            return
        rospy.loginfo(f"Feedback recebido Task9: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('\nExecuting Task 9: Publicar "100.0" no tópico /gripper_angle')
        active_task = 'TASK9'

        time.sleep(1.5)

        self.pub_gripper.publish(120.0)
        self.pub_gripper.publish(120.0)
        self.pub_gripper.publish(120.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/gripper_angle/feedback', Float32, self.feedback_cb)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task10(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/manipulator_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK10':
            return
        rospy.loginfo(f"Feedback recebido Task10: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, counter
        rospy.loginfo('\nExecuting Task 10: Publicar "11400.0" no tópico /manipulator_angle')
        active_task = 'TASK10'

        time.sleep(1)

        self.pub_gripper.publish(11400.0)
        self.pub_gripper.publish(11400.0)
        self.pub_gripper.publish(11400.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/manipulator_angle/feedback', Float32, self.feedback_cb)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        time.sleep(8)

        rospy.loginfo(f"Contador de blocos: {counter}")

        return 'completed'
    
class Task11(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/align_table', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK11':
            return
        rospy.loginfo(f"Feedback recebido Task11: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('\nExecuting Task 11: Publicar "start" no tópico /align_table')
        active_task = 'TASK11'

        time.sleep(1.5)

        self.pub_gripper.publish("start,0.20")
        self.pub_gripper.publish("start,0.20")
        self.pub_gripper.publish("start,0.20")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/align_table/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(8)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task12(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/edge_detect', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK12':
            return
        rospy.loginfo(f"Feedback recebido Task12: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('\nExecuting Task 12: Publicar "alinha a borda da mesa" no tópico /edge_detect')
        active_task = 'TASK12'

        time.sleep(1)

        self.pub_align.publish("start,esquerda")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/edge_detect/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(15)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task13(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_goal = rospy.Publisher('/goal_line_follower', Int32, queue_size=10)
        self.feedback_received = None

    def feedback_cb(self, data):
        if active_task != 'TASK13':
            return
        rospy.loginfo(f"Feedback recebido Task13: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, ids, counter, area_de_interesse, containers, stack, shelve, precision
        rospy.loginfo('\nExecuting Task 13: Publicar para iniciar o seguidor')
        active_task = 'TASK13'

        time.sleep(1)

        rospy.loginfo(f'\n\nBloco atual {ids[counter]}\n\n')

        if ids[counter] == containers[0] or ids[counter] == containers[1] or ids[counter] == containers[2] or ids[counter] == containers[3]:
            rospy.loginfo('Indo para a área 13')
            area_de_interesse = 3
            self.pub_goal.publish(13) # Containers
        elif ids[counter] == stack[0] or ids[counter] == stack[1]:
            rospy.loginfo('Indo para a área 14')
            area_de_interesse = 4
            self.pub_goal.publish(14) # Stacking
        else:
            rospy.loginfo('Indo para a área 12')
            area_de_interesse = 2
            self.pub_goal.publish(12) # Precisão

        counter += 1

        self.feedback_received = None
        rospy.Subscriber('/line_follower_feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(90) 
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        active_task = None

        return 'completed'

class Task14(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_goal = rospy.Publisher('/edge_detect', String, queue_size=10)
        self.feedback_received = None

    def feedback_cb(self, data):
        if active_task != 'TASK14':
            return
        rospy.loginfo(f"Feedback recebido Task14: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, ids, counter, area_de_interesse
        rospy.loginfo('\nExecuting Task 14: Publicar para iniciar o alinhamento con a direita')
        active_task = 'TASK14'

        time.sleep(1)

        if area_de_interesse == 3:
            self.pub_goal.publish("start,direita")
        else:
            rospy.loginfo(f"Nenhuma ação necessária para área de interesse: {area_de_interesse}")
            active_task = None
            return "completed"

        self.feedback_received = None
        rospy.Subscriber('/edge_detect/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(15) 
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        active_task = None

        return 'completed'

class Task15(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_goal = rospy.Publisher('/goal_find_container', String, queue_size=10)
        self.feedback_received = None

    def feedback_cb(self, data):
        if active_task != 'TASK15':
            return
        rospy.loginfo(f"Feedback recebido Task15: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, ids, counter, area_de_interesse
        rospy.loginfo('\nExecuting Task 15: Publicar para iniciar o alinhamento com o depósito')
        active_task = 'TASK15'

        time.sleep(1)

        if area_de_interesse == 3:
            self.pub_goal.publish(block_color)
        else:
            return 'completed'

        self.feedback_received = None
        rospy.Subscriber('/find_container_feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(25) 
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        active_task = None

        return 'completed'
    
class Task16(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/manipulator_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK16':
            return
        rospy.loginfo(f"Feedback recebido Task16: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, counter, area_de_interesse
        rospy.loginfo('\nExecuting Task 16: Publicar "-13700.0" no tópico /manipulator_angle')
        active_task = 'TASK16'

        time.sleep(1)

        if area_de_interesse == 3:
            self.pub_gripper.publish(-10000)
            self.pub_gripper.publish(-10000)
            self.pub_gripper.publish(-10000)
        elif area_de_interesse == 4:
            self.pub_gripper.publish(-13700.0)
            self.pub_gripper.publish(-13700.0)
            self.pub_gripper.publish(-13700.0)
        else:
            rospy.loginfo(f"Nenhuma ação necessária para área de interesse: {area_de_interesse}")
            active_task = None
            return "completed"

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/manipulator_angle/feedback', Float32, self.feedback_cb)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        time.sleep(8)
        
        rospy.loginfo(f"Contador de blocos: {counter}")
        return 'completed'

class Task17(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/align_table', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK17':
            return
        rospy.loginfo(f"Feedback recebido Task17: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, area_de_interesse
        active_task = 'TASK17'

        time.sleep(1.5)

        if area_de_interesse == 2:
            rospy.loginfo('\nExecuting Task 17: Publicar "start,0.15" no tópico /align_table')
            self.pub_gripper.publish("start,0.15")
            self.pub_gripper.publish("start,0.15")
            self.pub_gripper.publish("start,0.15")
        else:
            rospy.loginfo(f"\nNenhuma ação necessária para área de interesse: {area_de_interesse}")
            active_task = None
            return "completed"    

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/align_table/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(9)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task18(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/gripper_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK18':
            return
        rospy.loginfo(f"Feedback recebido Task18: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('\nExecuting Task 18: Publicar "start" no tópico /gripper_angle')
        active_task = 'TASK18'

        time.sleep(1.5)

        if area_de_interesse != 2:
            self.pub_gripper.publish(0.0)
            self.pub_gripper.publish(0.0)
            self.pub_gripper.publish(0.0)
        else:
            rospy.loginfo(f"Nenhuma ação necessária para área de interesse: {area_de_interesse}")
            active_task = None
            return "completed"

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/gripper_angle/feedback', Float32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(5)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task19(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/manipulator_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK19':
            return
        rospy.loginfo(f"Feedback recebido Task19: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('\nExecuting Task 19: Publicar "13700.0" no tópico /manipulator_angle')
        active_task = 'TASK19'

        time.sleep(1.5)

        if area_de_interesse == 3:
            self.pub_gripper.publish(10000)
            self.pub_gripper.publish(10000)
            self.pub_gripper.publish(10000)
        elif area_de_interesse == 4:
            self.pub_gripper.publish(13700.0)
            self.pub_gripper.publish(13700.0)
            self.pub_gripper.publish(13700.0)
        else:
            rospy.loginfo(f"Nenhuma ação necessária para área de interesse: {area_de_interesse}")
            active_task = None
            return "completed"

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/manipulator_angle/feedback', Float32, self.feedback_cb)

        time.sleep(8)     

        active_task = None

        return 'completed'
    
class Task20(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/move_time', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK20':
            return
        rospy.loginfo(f"Feedback recebido Task20: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo(f"\nExecuting Task 20: Andando para tras")

        time.sleep(1.5)
        active_task = 'TASK20'

        if area_de_interesse == 5 or area_de_interesse == 6:
            self.pub_align.publish("tras,2")
        else:
            rospy.loginfo(f"Nenhuma ação necessária para área de interesse: {area_de_interesse}")
            active_task = None
            return "completed"

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/move_time/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(10)
        while self.feedback_received not in [0, 1] and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task21(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_goal = rospy.Publisher('/goal_line_follower', Int32, queue_size=10)
        self.feedback_received = None

    def feedback_cb(self, data):
        if active_task != 'TASK21':
            return
        rospy.loginfo(f"Feedback recebido Task21: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, counter, containers, stack, shelve, precision
        rospy.loginfo('\nExecuting Task 21: Publicar para iniciar o seguidor')
        active_task = 'TASK21'

        time.sleep(1.5)

        rospy.loginfo(f'Area de interesse: {area_de_interesse}')

        if counter < 6:
            if area_de_interesse == 3:
                rospy.loginfo('Indo para a área 31')
                self.pub_goal.publish(31) # Containers
            else:
                rospy.loginfo('Indo para a área 41')
                self.pub_goal.publish(41) # Stack
        else:
            rospy.loginfo('Indo para o final!')
            self.pub_goal.publish(36)

        self.feedback_received = None
        rospy.Subscriber('/line_follower_feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(90) 
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        active_task = None

        return 'completed'
    
def main():
    rospy.init_node('scheduler_node')

    sm = smach.StateMachine(outcomes=['all_tasks_completed', 'all_tasks_failed'])
    sm.userdata.blocks_searched = 0

    with sm:
        smach.StateMachine.add('TASK1', Task1(), 
                               transitions={'completed': 'TASK2', 'failed': 'all_tasks_failed'})
        
        smach.StateMachine.add('TASK2', Task2(), 
                               transitions={'completed': 'TASK3', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK3', Task3(), 
                               transitions={'completed': 'TASK4', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK4', Task4(), 
                               transitions={'completed': 'TASK5', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK5', Task5(), 
                               transitions={'completed': 'TASK6', 'failed': 'all_tasks_failed'})
                
        smach.StateMachine.add('TASK6', Task6(), 
                               transitions={'completed': 'TASK7', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK7', Task7(), 
                               transitions={'completed': 'TASK8', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK8', Task8(), 
                               transitions={'completed': 'TASK9', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK9', Task9(), 
                                transitions={'completed': 'TASK10', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK10', Task10(), 
                                transitions={'completed': 'TASK11', 'failed': 'all_tasks_failed'})
        
        smach.StateMachine.add('TASK11', Task11(), 
                            transitions={'completed': 'TASK12', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK12', Task12(), 
                            transitions={'completed': 'TASK13', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK13', Task13(), 
                            transitions={'completed': 'TASK14', 'failed': 'all_tasks_failed'})
    
        smach.StateMachine.add('TASK14', Task14(), 
                                transitions={'completed': 'TASK15', 'failed': 'all_tasks_failed'})
        
        smach.StateMachine.add('TASK15', Task15(), 
                                transitions={'completed': 'TASK16', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK16', Task16(), 
                                transitions={'completed': 'TASK17', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK17', Task17(), 
                                transitions={'completed': 'TASK18', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK18', Task18(), 
                                transitions={'completed': 'TASK20', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK19', Task19(), 
                                transitions={'completed': 'TASK21', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK20', Task20(), 
                            transitions={'completed': 'TASK19', 'failed': 'all_tasks_failed'})
        
        smach.StateMachine.add('TASK21', Task21(), 
                            transitions={'completed': 'CHECK_BLOCK_COUNT', 'failed': 'all_tasks_failed'})

        def check_block_count(userdata):
            time.sleep(0.8) 

            rospy.loginfo(f'Blocos pegos {counter}/4')
            
            if counter < 6:
                rospy.loginfo('Procurando por mais blocos! \n')
                return 'search_more'
            else:
                rospy.loginfo('Todos os blocos foram pegos! \n')
                return 'completed'

        smach.StateMachine.add('CHECK_BLOCK_COUNT', smach.CBState(check_block_count, 
                                                                  outcomes=['search_more', 'completed'], 
                                                                  input_keys=['blocks_searched'], 
                                                                  output_keys=['blocks_searched']),
                               transitions={'search_more': 'TASK2',
                                            'completed': 'all_tasks_completed'})

    outcome = sm.execute()
    rospy.loginfo(f"Scheduler finalizado com o resultado: {outcome}")

if __name__ == '__main__':
    main()
