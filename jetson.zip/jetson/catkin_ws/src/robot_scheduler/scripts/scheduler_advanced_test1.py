#!/usr/bin/env python3

import rospy
import smach
import smach_ros
from geometry_msgs.msg import Twist
import time
from std_msgs.msg import Int32, String, Float32
import json

global block_counter 

global ordered_ids_position 
global original_ids_position 
global interest_block

counter = 0

interest_block = None

ordered_ids_position = []
original_ids_position = []

class Task1(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/gripper_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK1':
            return
        rospy.loginfo(f"Feedback recebido Task1: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 1: Publicar "start" no tópico /gripper_angle')
        active_task = 'TASK1'

        time.sleep(1.5)

        self.pub_gripper.publish(0.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/gripper_angle/feedback', Float32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(10)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'
        
class Task2(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/align_table', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK2':
            return
        rospy.loginfo(f"Feedback recebido Task2: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 2: Publicar "start" no tópico /align_table')
        active_task = 'TASK2'
        self.pub_align.publish("start,0.15")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/align_table/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(10)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task3(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/edge_detect', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK3':
            return
        rospy.loginfo(f"Feedback recebido Task4: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 3: Publicar "alinha a borda da mesa" no tópico /edge_detect')
        active_task = 'TASK3'

        time.sleep(1)

        self.pub_align.publish("start,esquerda")
        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/edge_detect/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(15)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task4(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/search_block', String, queue_size=10)
        self.feedback_received = None
        self.found_block_id = None
        self.subscriber = None
        self.found_block_subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK4':
            return
        rospy.loginfo(f"Feedback recebido Task4: {data.data}")
        self.feedback_received = data.data

    def found_block_cb(self, data):
        global interest_block 
        interest_block = data.data
        rospy.loginfo(f"Bloco encontrado com ID: {interest_block}")

    def execute(self, userdata):
        global active_task, interest_block
        rospy.loginfo(f"Executing Task 4: Procurando o bloco {interest_block}")

        time.sleep(1)
        active_task = 'TASK4'

        self.pub_align.publish("start,-1")
        rospy.loginfo(f"Publicando busca para o bloco: {interest_block}")

        self.feedback_received = None
        self.found_block_id = None
        self.subscriber = rospy.Subscriber('/search_block/feedback', Int32, self.feedback_cb)
        self.found_block_subscriber = rospy.Subscriber('/found_block', Int32, self.found_block_cb)

        timeout = rospy.Time.now() + rospy.Duration(30)
        while self.feedback_received not in [0, 1] and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()
        if self.found_block_subscriber:
            self.found_block_subscriber.unregister()

        active_task = None

        if self.feedback_received == 1:
            return 'completed'
        else:
            return 'failed'


class Task5(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/block_align', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK5':
            return
        rospy.loginfo(f"Feedback recebido Task5: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, interest_block
        rospy.loginfo(f"Executing Task 5: Alinhando ao bloco {interest_block}")

        time.sleep(1.5)
        active_task = 'TASK5'

        self.pub_align.publish(f"{interest_block}")
        rospy.loginfo(f"Publicando alinhar com o bloco: {interest_block}")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/block_align/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(30)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task6(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/mapping_ids', Int32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def mapped_cb(self, data):
        global active_task, ordered_ids_position, original_ids_position

        # Verifica se a tarefa ativa é a correta
        if active_task != 'TASK6':
            return

        rospy.loginfo(f"Feedback recebido Task6: {data.data}")
        self.feedback_received = data.data

        try:
            # Divide a string recebida em duas partes separadas por ";"
            original_order_str, ordered_ids_str = data.data.split(";")

            # Convertendo as strings de volta para listas de inteiros
            original_order = list(map(int, original_order_str.split(",")))
            ordered_ids = list(map(int, ordered_ids_str.split(",")))

            rospy.loginfo(f"Original Order: {original_order}")
            rospy.loginfo(f"Ordered IDs: {ordered_ids}")

            # Salvando os dados em variáveis globais
            original_ids_position = original_order
            ordered_ids_position = ordered_ids

            # Também pode salvar em variáveis da classe, se necessário
            self.original_ids_position = original_order
            self.ordered_ids_position = ordered_ids

            rospy.loginfo("Dados salvos com sucesso em variáveis globais e locais.")
            
        except ValueError as e:
            rospy.logerr(f"Erro ao processar os dados recebidos: {e}")
        except Exception as e:
            rospy.logerr(f"Erro inesperado: {e}")

    def execute(self, userdata):
        global active_task
        rospy.loginfo(f"Executing Task 6: Mapeando e ordenando os ids")

        time.sleep(3)
        active_task = 'TASK6'

        self.pub_align.publish(1)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/mapped_data', String, self.mapped_cb)

        timeout = rospy.Time.now() + rospy.Duration(30)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'
    
class Task7(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/block_align', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK7':
            return
        rospy.loginfo(f"Feedback recebido Task7: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo(f"Executing Task 7: Alinhando ao bloco {original_ids_position[-1]}")

        time.sleep(1.5)
        active_task = 'TASK7'

        self.pub_align.publish(f"{original_ids_position[-1]}")
        rospy.loginfo(f"Publicando para buscar bloco a esquerda: {original_ids_position[-1]}")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/block_align/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(30)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task8(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/search_id_decision', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK8':
            return
        rospy.loginfo(f"Feedback recebido Task78 {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, interest_block
        rospy.loginfo("Executing Task 8: Buscando a esquerda")

        time.sleep(1.5)
        active_task = 'TASK8'

        interest_block = ordered_ids_position[counter] #Primeira posição do meu vetor

        rospy.loginfo(f"Publicando para buscar {interest_block}")
        self.pub_align.publish(f"{-1,-1,interest_block}")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/search_id_decision_feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(30)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'
    
class Task9(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/block_align', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK9':
            return
        rospy.loginfo(f"Feedback recebido Task9: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, interest_block
        rospy.loginfo(f"Executing Task 9: Alinhando ao bloco {interest_block}")

        time.sleep(3)
        active_task = 'TASK9'

        self.pub_align.publish(f"{interest_block}")
        rospy.loginfo(f"Publicando alinhar com o bloco: {interest_block}")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/block_align/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(15)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task10(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/move_time', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK10':
            return
        rospy.loginfo(f"Feedback recebido Task10: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, interest_blocks
        rospy.loginfo(f"Executing Task 10: Andando para frente")

        time.sleep(1)
        active_task = 'TASK10'

        self.pub_align.publish("frente,0.4")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/move_time/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(15)
        while self.feedback_received not in [0, 1] and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task11(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/manipulator_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK11':
            return
        rospy.loginfo(f"Feedback recebido Task11: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 11: Publicar "-11000.0" no tópico /manipulator_angle')
        active_task = 'TASK11'

        time.sleep(1.5)

        self.pub_gripper.publish(-11400.0)
        self.pub_gripper.publish(-11400.0)
        self.pub_gripper.publish(-11400.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/manipulator_angle/feedback', Float32, self.feedback_cb)

        # timeout = rospy.Time.now() + rospy.Duration(10)
        # while self.feedback_received is None and rospy.Time.now() < timeout:
        #     rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        time.sleep(10)

        return 'completed'

class Task12(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/gripper_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK12':
            return
        rospy.loginfo(f"Feedback recebido Task12: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 12: Publicar "120.0" no tópico /gripper_angle')
        active_task = 'TASK12'

        time.sleep(1.5)

        self.pub_gripper.publish(120.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/gripper_angle/feedback', Float32, self.feedback_cb)

        # timeout = rospy.Time.now() + rospy.Duration(5)
        # while self.feedback_received is None and rospy.Time.now() < timeout:
        #     rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None
        time.sleep(1.5)

        return 'completed'

class Task13(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/manipulator_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK13':
            return
        rospy.loginfo(f"Feedback recebido Task13: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, counter
        rospy.loginfo('Executing Task 13: Publicar "11000.0" no tópico /manipulator_angle')
        active_task = 'TASK13'

        time.sleep(1.5)

        self.pub_gripper.publish(11400.0)
        self.pub_gripper.publish(11400.0)
        self.pub_gripper.publish(11400.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/manipulator_angle/feedback', Float32, self.feedback_cb)

        # timeout = rospy.Time.now() + rospy.Duration(10)
        # while self.feedback_received is None and rospy.Time.now() < timeout:
        #     rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        time.sleep(8)

        rospy.loginfo(f"Contador de blocos: {counter}")
        return 'completed'

###################################3 colocar para ir para tras??

class Task14(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/search_id_decision', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK14':
            return
        rospy.loginfo(f"Feedback recebido Task14: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, interest_block, counter
        rospy.loginfo("Executing Task 14: Buscando a esquerda")

        time.sleep(1.5)
        active_task = 'TASK14'

        last_interest_block = interest_block
        interest_block = original_ids_position[counter]

        rospy.loginfo(f"Publicando para buscar {interest_block}")
        self.pub_align.publish(f"{original_ids_position.index(last_interest_block),counter,interest_block}")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/search_id_decision_feedback', Int32, self.feedback_cb)
        
        counter += 1

        timeout = rospy.Time.now() + rospy.Duration(30)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)


        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task15(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/block_align', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK15':
            return
        rospy.loginfo(f"Feedback recebido Task15: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, interest_block
        rospy.loginfo(f"Executing Task 15: Alinhando ao bloco {interest_block}")

        time.sleep(1.5)
        active_task = 'TASK15'

        self.pub_align.publish(f"{interest_block}")
        rospy.loginfo(f"Publicando alinhar com o bloco: {interest_block}")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/block_align/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(30)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task16(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/align_table', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK16':
            return
        rospy.loginfo(f"Feedback recebido Task16: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 16: Publicar "start" no tópico /align_table')
        active_task = 'TASK16'
        self.pub_align.publish("start,0.08")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/align_table/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(10)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task17(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/manipulator_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK17':
            return
        rospy.loginfo(f"Feedback recebido Task17: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 17: Publicar "-11000.0" no tópico /manipulator_angle')
        active_task = 'TASK17'

        time.sleep(1.5)

        self.pub_gripper.publish(-11400.0)
        self.pub_gripper.publish(-11400.0)
        self.pub_gripper.publish(-11400.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/manipulator_angle/feedback', Float32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(15)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        time.sleep(8)

        return 'completed'

class Task18(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/gripper_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK18':
            return
        rospy.loginfo(f"Feedback recebido Task18: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 18: Publicar "0.0" no tópico /gripper_angle')
        active_task = 'TASK18'

        time.sleep(1.5)

        self.pub_gripper.publish(0.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/gripper_angle/feedback', Float32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(15)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task19(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/manipulator_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK19':
            return
        rospy.loginfo(f"Feedback recebido Task19: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, counter
        rospy.loginfo('Executing Task 19: Publicar "11000.0" no tópico /manipulator_angle')
        active_task = 'TASK19'

        time.sleep(1.5)

        self.pub_gripper.publish(11400.0)
        self.pub_gripper.publish(11400.0)
        self.pub_gripper.publish(11400.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/manipulator_angle/feedback', Float32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(15)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        rospy.loginfo(f"Contador de blocos: {counter}")
        return 'completed'

class Task20(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/align_table', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK20':
            return
        rospy.loginfo(f"Feedback recebido Task20: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 2: Publicar "start" no tópico /align_table')
        active_task = 'TASK20'
        self.pub_align.publish("start,0.20")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/align_table/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(10)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

##### Inicio do loop de busca aqui

class Task21(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/search_id_decision', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK21':
            return
        rospy.loginfo(f"Feedback recebido Task21: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, interest_block
        rospy.loginfo("Executing Task 21: Buscando por id de interesse")

        time.sleep(1.5)
        active_task = 'TASK21'

        interest_block = ordered_ids_position[counter]

        rospy.loginfo(f"Publicando para buscar {interest_block}")
        self.pub_align.publish(f"{counter-1,original_ids_position.index(interest_block),interest_block}")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/search_id_decision_feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(30)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task22(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/block_align', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK22':
            return
        rospy.loginfo(f"Feedback recebido Task22: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, interest_block
        rospy.loginfo(f"Executing Task 22: Alinhando ao bloco {interest_block}")

        time.sleep(1.5)
        active_task = 'TASK22'

        self.pub_align.publish(f"{interest_block}")
        rospy.loginfo(f"Publicando alinhar com o bloco: {interest_block}")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/block_align/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(30)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task23(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/move_time', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK23':
            return
        rospy.loginfo(f"Feedback recebido Task23: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, interest_blocks
        rospy.loginfo(f"Executing Task 23: Andando para frente")

        time.sleep(1.5)
        active_task = 'TASK7'

        self.pub_align.publish("frente,0.4")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/move_time/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(5)
        while self.feedback_received not in [0, 1] and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task24(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/manipulator_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK24':
            return
        rospy.loginfo(f"Feedback recebido Task24: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 24: Publicar "-11000.0" no tópico /manipulator_angle')
        active_task = 'TASK8'

        time.sleep(1.5)

        self.pub_gripper.publish(-11400.0)
        self.pub_gripper.publish(-11400.0)
        self.pub_gripper.publish(-11400.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/manipulator_angle/feedback', Float32, self.feedback_cb)

        # timeout = rospy.Time.now() + rospy.Duration(10)
        # while self.feedback_received is None and rospy.Time.now() < timeout:
        #     rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        time.sleep(8)

        return 'completed'
    
class Task25(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/gripper_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK25':
            return
        rospy.loginfo(f"Feedback recebido Task25: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 25: Publicar "120.0" no tópico /gripper_angle')
        active_task = 'TASK9'

        time.sleep(1.5)

        self.pub_gripper.publish(120.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/gripper_angle/feedback', Float32, self.feedback_cb)

        # timeout = rospy.Time.now() + rospy.Duration(5)
        # while self.feedback_received is None and rospy.Time.now() < timeout:
        #     rospy.sleep(0.1)

        time.sleep(1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task26(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/manipulator_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK26':
            return
        rospy.loginfo(f"Feedback recebido Task26: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, counter
        rospy.loginfo('Executing Task 26: Publicar "11000.0" no tópico /manipulator_angle')
        active_task = 'TASK26'

        time.sleep(1.5)

        self.pub_gripper.publish(11400.0)
        self.pub_gripper.publish(11400.0)
        self.pub_gripper.publish(11400.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/manipulator_angle/feedback', Float32, self.feedback_cb)

        # timeout = rospy.Time.now() + rospy.Duration(10)
        # while self.feedback_received is None and rospy.Time.now() < timeout:
        #     rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        rospy.loginfo(f"Contador de blocos: {counter}")

        time.sleep(8)

        return 'completed'

class Task27(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/search_id_decision', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK27':
            return
        rospy.loginfo(f"Feedback recebido Task27: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, interest_block, counter
        rospy.loginfo("Executing Task 27")

        time.sleep(1.5)
        active_task = 'TASK27'

        last_interest_block = interest_block
        interest_block = ordered_ids_position[counter-1]

        rospy.loginfo(f"Publicando para buscar {interest_block}")
        self.pub_align.publish(f"{original_ids_position.index(last_interest_block),counter-1,interest_block}")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/search_id_decision_feedback', Int32, self.feedback_cb)

        counter += 1

        timeout = rospy.Time.now() + rospy.Duration(30)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task28(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/block_align', String, queue_size=10)
        self.pub_move_time = rospy.Publisher('/move_time', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK28':
            return
        rospy.loginfo(f"Feedback recebido Task28: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, interest_block
        rospy.loginfo(f"Executing Task 28: Alinhando ao bloco {interest_block}")

        time.sleep(1.5)
        active_task = 'TASK28'

        self.pub_align.publish(f"{interest_block}")
        rospy.loginfo(f"Publicando alinhar com o bloco: {interest_block}")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/block_align/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(30)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        self.pub_move_time.publish("direita,2.5")
        rospy.sleep(5)
        
        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'


class Task29(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/align_table', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK29':
            return
        rospy.loginfo(f"Feedback recebido Task29: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 29: Publicar "start" no tópico /align_table')
        active_task = 'TASK29'
        self.pub_align.publish("start,0.09")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/align_table/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(10)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task30(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/manipulator_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK30':
            return
        rospy.loginfo(f"Feedback recebido Task30: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 30: Publicar "-11000.0" no tópico /manipulator_angle')
        active_task = 'TASK30'

        time.sleep(1.5)

        self.pub_gripper.publish(-11400.0)
        self.pub_gripper.publish(-11400.0)
        self.pub_gripper.publish(-11400.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/manipulator_angle/feedback', Float32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(15)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        time.sleep(8)

        return 'completed'

class Task31(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/gripper_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK31':
            return
        rospy.loginfo(f"Feedback recebido Task31: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 31: Publicar "0.0" no tópico /gripper_angle')
        active_task = 'TASK31'

        time.sleep(1.5)

        self.pub_gripper.publish(0.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/gripper_angle/feedback', Float32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(15)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task32(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/manipulator_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK32':
            return
        rospy.loginfo(f"Feedback recebido Task32: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, counter
        rospy.loginfo('Executing Task 32: Publicar "11000.0" no tópico /manipulator_angle')
        active_task = 'TASK32'

        time.sleep(1.5)

        self.pub_gripper.publish(11400.0)
        self.pub_gripper.publish(11400.0)
        self.pub_gripper.publish(11400.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/manipulator_angle/feedback', Float32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(15)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        time.sleep(8)

        rospy.loginfo(f"Contador de blocos: {counter}")
        return 'completed'

class Task33(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/align_table', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK33':
            return
        rospy.loginfo(f"Feedback recebido Task33: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task33: Publicar "start" no tópico /align_table')
        active_task = 'TASK33'
        self.pub_align.publish("start,0.20")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/align_table/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(10)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task34(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/edge_detect', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK34':
            return
        rospy.loginfo(f"Feedback recebido Task34: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task34: Publicar "start" no tópico /edge_detect')
        active_task = 'TASK34'

        self.pub_align.publish("start,esquerda")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/edge_detect/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(15)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        return 'completed'

class Task35(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_goal = rospy.Publisher('/goal_line_follower', Int32, queue_size=10)
        self.feedback_received = None

    def feedback_cb(self, data):
        if active_task != 'TASK35':
            return
        rospy.loginfo(f"Feedback recebido Task35: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 35: Publicar para iniciar o seguidor')
        active_task = 'TASK35'

        time.sleep(1)

        self.pub_goal.publish(16)

        self.feedback_received = None
        rospy.Subscriber('/line_follower_feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(90) 
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        active_task = None

        return 'completed'

def main():
    rospy.init_node('scheduler_node')

    sm = smach.StateMachine(outcomes=['all_tasks_completed', 'all_tasks_failed'])

    with sm:
        smach.StateMachine.add('TASK1', Task1(),
                            transitions={'completed': 'TASK2', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK2', Task2(),
                            transitions={'completed': 'TASK3', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK3', Task3(),
                            transitions={'completed': 'TASK4', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK4', Task4(),
                            transitions={'completed': 'TASK5', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK5', Task5(),
                            transitions={'completed': 'TASK6', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK6', Task6(),
                            transitions={'completed': 'TASK7', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK7', Task7(),
                            transitions={'completed': 'TASK8', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK8', Task8(),
                            transitions={'completed': 'TASK9', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK9', Task9(),
                            transitions={'completed': 'TASK10', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK10', Task10(),
                            transitions={'completed': 'TASK11', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK11', Task11(),
                            transitions={'completed': 'TASK12', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK12', Task12(),
                            transitions={'completed': 'TASK13', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK13', Task13(),
                            transitions={'completed': 'TASK14', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK14', Task14(),
                            transitions={'completed': 'TASK15', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK15', Task15(),
                            transitions={'completed': 'TASK16', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK16', Task16(),
                            transitions={'completed': 'TASK17', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK17', Task17(),
                            transitions={'completed': 'TASK18', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK18', Task18(),
                            transitions={'completed': 'TASK19', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK19', Task19(),
                            transitions={'completed': 'TASK20', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK20', Task20(),
                            transitions={'completed': 'TASK21', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK21', Task21(),
                            transitions={'completed': 'TASK22', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK22', Task22(),
                            transitions={'completed': 'TASK23', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK23', Task23(),
                            transitions={'completed': 'TASK24', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK24', Task24(),
                            transitions={'completed': 'TASK25', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK25', Task25(),
                            transitions={'completed': 'TASK26', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK26', Task26(),
                            transitions={'completed': 'TASK27', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK27', Task27(),
                            transitions={'completed': 'TASK28', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK28', Task28(),
                            transitions={'completed': 'TASK29', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK29', Task29(),
                            transitions={'completed': 'TASK30', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK30', Task30(),
                            transitions={'completed': 'TASK31', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK31', Task31(),
                            transitions={'completed': 'TASK32', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK32', Task32(),
                            transitions={'completed': 'TASK33', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK33', Task33(),
                            transitions={'completed': 'CHECK_BLOCK_COUNT', 'failed': 'all_tasks_failed'})
        
        smach.StateMachine.add('TASK34', Task34(),
                            transitions={'completed': 'TASK35', 'failed': 'all_tasks_failed'})
        
        smach.StateMachine.add('TASK35', Task35(),
                            transitions={'completed': 'all_tasks_completed', 'failed': 'all_tasks_failed'})

        def check_block_count(userdata):
            time.sleep(0.8) 

            rospy.loginfo(f'Blocos pegos {counter}/5')
            
            if counter < 5:
                rospy.loginfo('Alinhando mais blocos! \n')
                return 'search_more'
            else:
                rospy.loginfo('Todos os blocos foram alinhados! \n')
                return 'completed'

        smach.StateMachine.add('CHECK_BLOCK_COUNT', smach.CBState(check_block_count, 
                                                                  outcomes=['search_more', 'completed'], 
                                                                  input_keys=['blocks_searched'], 
                                                                  output_keys=['blocks_searched']),
                               transitions={'search_more': 'TASK21',
                                            'completed': 'TASK34'})


    outcome = sm.execute()
    rospy.loginfo(f"Scheduler finalizado com o resultado: {outcome}")

if __name__ == '__main__':
    main()
