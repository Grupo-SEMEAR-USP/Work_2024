#!/usr/bin/env python3

import rospy
import smach
import smach_ros
import time
from std_msgs.msg import Int32, String, Float32
import subprocess
from robot_arm_control.msg import MoveToPoseCommand

interest_block = None
counter = 0
block_color = None

color = ["blue", "blue", "blue", "red"]
containers = ["blue", "blue", "blue", "red"]

class Task1(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/gripper_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK1':
            return
        rospy.loginfo(f"Feedback recebido Task1: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 1: Publicar "start" no tópico /gripper_angle')
        active_task = 'TASK1'

        time.sleep(1.5)

        self.pub_gripper.publish(0.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/gripper_angle/feedback', Float32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(10)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        if self.feedback_received == 1:
            return 'completed'
        else:
            return 'failed'

class Task2(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/align_table', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK2':
            return
        rospy.loginfo(f"Feedback recebido Task2: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 2: Publicar "start" no tópico /align_table')
        active_task = 'TASK2'
        self.pub_align.publish("start")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/align_table/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(10)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        # if self.feedback_received == 1:
        return 'completed'
        # else:
            # return 'failed'

class Task3(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/edge_detect', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK3':
            return
        rospy.loginfo(f"Feedback recebido Task3: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 3: Publicar "alinha a borda da mesa" no tópico /edge_detect')
        active_task = 'TASK3'
        time.sleep(1)
        self.pub_align.publish("start,esquerda")
        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/edge_detect/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(15)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        # if self.feedback_received == 1:
        return 'completed'
        # else:
        #     return 'failed'

class Task4(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/search_block', String, queue_size=10)
        self.feedback_received = None
        self.found_block_id = None
        self.subscriber = None
        self.found_block_subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK4':
            return
        rospy.loginfo(f"Feedback recebido Task4: {data.data}")
        self.feedback_received = data.data

    def found_block_cb(self, data):
        global interest_block 
        interest_block = data.data
        rospy.loginfo(f"Bloco encontrado com ID: {interest_block}")

    def execute(self, userdata):
        global active_task, interest_block
        rospy.loginfo(f"Executing Task 4: Procurando o bloco {interest_block}")

        time.sleep(1)
        active_task = 'TASK4'

        self.pub_align.publish("start,-1")
        rospy.loginfo(f"Publicando busca para o bloco: {interest_block}")

        self.feedback_received = None
        self.found_block_id = None
        self.subscriber = rospy.Subscriber('/search_block/feedback', Int32, self.feedback_cb)
        self.found_block_subscriber = rospy.Subscriber('/found_block', Int32, self.found_block_cb)

        timeout = rospy.Time.now() + rospy.Duration(40)
        while self.feedback_received not in [0, 1] and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()
        if self.found_block_subscriber:
            self.found_block_subscriber.unregister()

        active_task = None

        if self.feedback_received == 1:
            return 'completed'
        else:
            return 'failed'


class Task5(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/block_align', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK5':
            return
        rospy.loginfo(f"Feedback recebido Task5: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, interest_block
        rospy.loginfo(f"Executing Task 5: Alinhando ao bloco {interest_block}")

        time.sleep(3)
        active_task = 'TASK5'

        self.pub_align.publish(f"{interest_block}")
        rospy.loginfo(f"Publicando alinhar com o bloco: {interest_block}")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/block_align/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(30)
        while self.feedback_received not in [0, 1] and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        if self.feedback_received == 1:
            return 'completed'
        else:
            return 'failed'

class Task6(smach.State):

    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        
    def execute(self, userdata):
        global active_task, block_color
        rospy.loginfo("Executing Task 6: Aguardando detecção da cor do bloco")

        time.sleep(1)
        active_task = 'TASK6'

        rospy.loginfo(f"Cor: {color[counter]}")

        block_color = color[counter]

        return 'completed'


class Task7(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/move_time', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK7':
            return
        rospy.loginfo(f"Feedback recebido Task7: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, interest_blocks
        rospy.loginfo(f"Executing Task 7: Andando para frente")

        time.sleep(1)
        active_task = 'TASK7'

        self.pub_align.publish("frente,0.4")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/move_time/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(10)
        while self.feedback_received not in [0, 1] and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        if self.feedback_received == 1:
            return 'completed'
        else:
            return 'failed'

class Task8(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/manipulator_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK8':
            return
        rospy.loginfo(f"Feedback recebido Task8: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 8: Publicar "-11000.0" no tópico /manipulator_angle')
        active_task = 'TASK8'

        time.sleep(2)

        self.pub_gripper.publish(-11400.0)
        self.pub_gripper.publish(-11400.0)
        self.pub_gripper.publish(-11400.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/manipulator_angle/feedback', Float32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(15)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        time.sleep(8)

        if self.feedback_received == 1:
            return 'completed'
        else:
            return 'failed'

class Task9(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/gripper_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK9':
            return
        rospy.loginfo(f"Feedback recebido Task9: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 9: Publicar "85.0" no tópico /gripper_angle')
        active_task = 'TASK9'

        time.sleep(2)

        self.pub_gripper.publish(85.0)
        self.pub_gripper.publish(85.0)
        self.pub_gripper.publish(85.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/gripper_angle/feedback', Float32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(15)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        if self.feedback_received == 1:
            return 'completed'
        else:
            return 'failed'

class Task10(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/manipulator_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK10':
            return
        rospy.loginfo(f"Feedback recebido Task10: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, counter
        rospy.loginfo('Executing Task 10: Publicar "11000.0" no tópico /manipulator_angle')
        active_task = 'TASK10'

        time.sleep(1)

        self.pub_gripper.publish(11400.0)
        self.pub_gripper.publish(11400.0)
        self.pub_gripper.publish(11400.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/manipulator_angle/feedback', Float32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(15)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        time.sleep(8)

        counter += 1
        rospy.loginfo(f"Contador de blocos: {counter}")

        return 'completed'

class Task11(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/align_table', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK11':
            return
        rospy.loginfo(f"Feedback recebido Task11: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 11: Publicar "start" no tópico /align_table')
        active_task = 'TASK11'

        time.sleep(2)

        self.pub_align.publish("start")

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/align_table/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(15)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)
            
        active_task = None

        if self.subscriber:
            self.subscriber.unregister()


        # if self.feedback_received == 1:
        return 'completed'
        # else:
        #     return 'failed'

class Task12(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_align = rospy.Publisher('/edge_detect', String, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK12':
            return
        rospy.loginfo(f"Feedback recebido Task12: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 12: Publicar "alinha a borda da mesa" no tópico /edge_detect')
        active_task = 'TASK12'
        time.sleep(1)
        self.pub_align.publish("start,esquerda")
        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/edge_detect/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(15)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        if self.subscriber:
            self.subscriber.unregister()

        active_task = None

        if self.feedback_received == 1:
            return 'completed'
        else:
            return 'failed'

class Task13(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_goal = rospy.Publisher('/goal_line_follower', Int32, queue_size=10)
        self.feedback_received = None

    def feedback_cb(self, data):
        if active_task != 'TASK13':
            return
        rospy.loginfo(f"Feedback recebido Task13: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 13: Publicar para iniciar o seguidor')
        active_task = 'TASK13'

        time.sleep(2)

        self.pub_goal.publish(13)

        self.feedback_received = None
        rospy.Subscriber('/line_follower_feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(90) 
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        active_task = None

        if self.feedback_received == 1:
            return 'completed'
        else:
            return 'failed'
    
class Task14(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_goal = rospy.Publisher('/edge_detect', String, queue_size=10)
        self.feedback_received = None

    def feedback_cb(self, data):
        if active_task != 'TASK14':
            return
        rospy.loginfo(f"Feedback recebido Task14: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 14: Publicar para iniciar o alinhamento con a direita')
        active_task = 'TASK14'

        time.sleep(1)

        self.pub_goal.publish("start,direita")

        self.feedback_received = None
        rospy.Subscriber('/edge_detect/feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(90) 
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.loginfo('Tempo!!')
            rospy.sleep(0.1)


        active_task = None

        if self.feedback_received == 1:
            return 'completed'
        else:
            return 'failed'

class Task15(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_goal = rospy.Publisher('/goal_find_container', String, queue_size=10)
        self.feedback_received = None

    def feedback_cb(self, data):
        if active_task != 'TASK15':
            return
        rospy.loginfo(f"Feedback recebido Task15: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, containers, counter, block_color
        rospy.loginfo('Executing Task 15: Publicar para iniciar o alinhamento com o depósito')
        active_task = 'TASK15'

        time.sleep(1)

        self.pub_goal.publish(block_color)

        self.feedback_received = None
        rospy.Subscriber('/find_container_feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(60) 
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        active_task = None

        return 'completed'

class Task16(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/manipulator_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK16':
            return
        rospy.loginfo(f"Feedback recebido Task16: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 16: Publicar "-9000.0" no tópico /manipulator_angle')
        active_task = 'TASK16'

        time.sleep(2)

        self.pub_gripper.publish(-10000.0)
        self.pub_gripper.publish(-10000.0)
        self.pub_gripper.publish(-10000.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/manipulator_angle/feedback', Float32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(15)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        active_task = None

        return 'completed'

class Task17(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/gripper_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK17':
            return
        rospy.loginfo(f"Feedback recebido Task17: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 17: Publicar "0.0" no tópico /gripper_angle')
        active_task = 'TASK17'

        time.sleep(2)

        self.pub_gripper.publish(0.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/gripper_angle/feedback', Float32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(15)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        active_task = None

        if self.feedback_received == 1:
            return 'completed'
        else:
            return 'failed'

class Task18(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_gripper = rospy.Publisher('/manipulator_angle', Float32, queue_size=10)
        self.feedback_received = None
        self.subscriber = None

    def feedback_cb(self, data):
        global active_task
        if active_task != 'TASK18':
            return
        rospy.loginfo(f"Feedback recebido Task18: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task, counter
        rospy.loginfo('Executing Task 18: Publicar "9000.0" no tópico /manipulator_angle')
        active_task = 'TASK18'

        time.sleep(1)

        self.pub_gripper.publish(10000.0)
        self.pub_gripper.publish(10000.0)
        self.pub_gripper.publish(10000.0)

        self.feedback_received = None
        self.subscriber = rospy.Subscriber('/manipulator_angle/feedback', Float32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(15)
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        active_task = None

        rospy.sleep(8)

        return 'completed'

class Task19(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])
        self.pub_goal = rospy.Publisher('/goal_line_follower', Int32, queue_size=10)
        self.feedback_received = None

    def feedback_cb(self, data):
        if active_task != 'TASK19':
            return
        rospy.loginfo(f"Feedback recebido Task19: {data.data}")
        self.feedback_received = data.data

    def execute(self, userdata):
        global active_task
        rospy.loginfo('Executing Task 19: Publicar para iniciar o seguidor')
        active_task = 'TASK19'

        time.sleep(1)

        if counter < 2:
            rospy.loginfo('Recomeçando!')
            self.pub_goal.publish(31)
        else:
            rospy.loginfo('Indo para o final!')
            self.pub_goal.publish(36)

        self.feedback_received = None
        rospy.Subscriber('/line_follower_feedback', Int32, self.feedback_cb)

        timeout = rospy.Time.now() + rospy.Duration(90) 
        while self.feedback_received is None and rospy.Time.now() < timeout:
            rospy.sleep(0.1)

        active_task = None

        if self.feedback_received == 1:
            return 'completed'
        else:
            return 'failed'


def main():
    rospy.init_node('scheduler_node')

    sm = smach.StateMachine(outcomes=['all_tasks_completed', 'all_tasks_failed'])
    sm.userdata.blocks_searched = 0

    with sm:
        smach.StateMachine.add('TASK1', Task1(), 
                               transitions={'completed': 'TASK2', 'failed': 'all_tasks_failed'})
        
        smach.StateMachine.add('TASK2', Task2(), 
                               transitions={'completed': 'TASK3', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK3', Task3(), 
                               transitions={'completed': 'TASK4', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK4', Task4(), 
                               transitions={'completed': 'TASK5', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK5', Task5(), 
                               transitions={'completed': 'TASK6', 'failed': 'all_tasks_failed'})
        
        smach.StateMachine.add('TASK6', Task6(), 
                               transitions={'completed': 'TASK7', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK7', Task7(), 
                               transitions={'completed': 'TASK8', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK8', Task8(), 
                               transitions={'completed': 'TASK9', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK9', Task9(), 
                                transitions={'completed': 'TASK10', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK10', Task10(), 
                                transitions={'completed': 'TASK11', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK11', Task11(), 
                                transitions={'completed': 'TASK12', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK12', Task12(), 
                                transitions={'completed': 'TASK13', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK13', Task13(), 
                                transitions={'completed': 'TASK15', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK14', Task14(), 
                                transitions={'completed': 'TASK15', 'failed': 'all_tasks_failed'})
        
        smach.StateMachine.add('TASK15', Task15(), 
                                transitions={'completed': 'TASK16', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK16', Task16(), 
                                transitions={'completed': 'TASK17', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK17', Task17(), 
                                transitions={'completed': 'TASK18', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK18', Task18(), 
                                transitions={'completed': 'TASK19', 'failed': 'all_tasks_failed'})

        smach.StateMachine.add('TASK19', Task19(), 
                                transitions={'completed': 'CHECK_BLOCK_COUNT', 'failed': 'all_tasks_failed'})

        def check_block_count(userdata):
            time.sleep(0.8) 

            rospy.loginfo(f'Blocos pegos {counter}/4')
            
            if counter < 2:
                rospy.loginfo('Procurando por mais blocos! \n')
                return 'search_more'
            else:
                rospy.loginfo('Todos os blocos foram pegos! \n')
                return 'completed'

        smach.StateMachine.add('CHECK_BLOCK_COUNT', smach.CBState(check_block_count, 
                                                                  outcomes=['search_more', 'completed'], 
                                                                  input_keys=['blocks_searched'], 
                                                                  output_keys=['blocks_searched']),
                               transitions={'search_more': 'TASK2',
                                            'completed': 'all_tasks_completed'})

    outcome = sm.execute()
    exit()

if __name__ == '__main__':
    main()
    # rospy.spin()
