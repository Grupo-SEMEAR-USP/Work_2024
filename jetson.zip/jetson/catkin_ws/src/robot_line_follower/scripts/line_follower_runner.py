#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
import cv2
import numpy as np
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from std_msgs.msg import Float32, Int32
from std_msgs.msg import String
import time
import rospy

feedback_pub = None

''' (Defining Variables For Line Follower)

turn_side = 1 - Virar à esquerda
turn_side = 2 - Virar à direita

turn_at_intersection = N° da intrsecção para virar (1, 2, 3, 4)

lost_line_turn = 0 - Andar reto até achar a linha
lost_line_turn = 1 - Virar à esquerda se perder a linha
lost_line_turn = 2 - Virar à direita se perder a linha

side_surpass = 1 - Fazer a ultrapassagem pela esquerda se encontrar obstáculo
side_surpass = 2 - Fazer a ultrapassagem pela direita se encontrar obstáculo

time_delay = t - Tempo até iniciar a contagem das intersecções
'''

#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Image
import cv2
import numpy as np
from std_msgs.msg import Float32  # Corrigido para importar Float32

def imgmsg_to_numpy(img_msg):
    """
    Converte uma mensagem sensor_msgs/Image para um array NumPy.
    """
    dtype = np.uint8
    img_np = np.frombuffer(img_msg.data, dtype=dtype)
    
    if img_msg.encoding == 'bgr8':
        img_np = img_np.reshape((img_msg.height, img_msg.width, 3))
    elif img_msg.encoding == 'rgb8':
        img_np = img_np.reshape((img_msg.height, img_msg.width, 3))
        img_np = cv2.cvtColor(img_np, cv2.COLOR_RGB2BGR)
    elif img_msg.encoding == 'mono8':
        img_np = img_np.reshape((img_msg.height, img_msg.width))
    else:
        raise NotImplementedError(f"Tipo de codificação {img_msg.encoding} não implementado")
    
    return img_np

def numpy_to_imgmsg(np_img, encoding='bgr8'):
    """
    Converte um array NumPy para uma mensagem sensor_msgs/Image.
    """
    img_msg = Image()
    img_msg.height = np_img.shape[0]
    img_msg.width = np_img.shape[1]
    img_msg.encoding = encoding
    img_msg.is_bigendian = 0
    if encoding == 'bgr8' or encoding == 'rgb8':
        img_msg.step = img_msg.width * 3
    elif encoding == 'mono8':
        img_msg.step = img_msg.width
    else:
        raise NotImplementedError(f"Tipo de codificação {encoding} não implementado")
    img_msg.data = np_img.tobytes()
    return img_msg

# Constantes
LINEAR_SPEED = 0.2
KP_BASE = 1.5 / 1000
MIN_AREA_TRACK = 100
DETECTION_REGION_PERCENTAGE = 0.10
MOVING_AVERAGE_SIZE = 7
MIN_LINE_PROPORTION = 0.1
MIN_PERSISTENCE_FRAMES = 3
ANGULAR_Z_DURATION = 3  # Tempo em segundos para o movimento em angular.z
FOLLOWER_INTERVAL = 5  # Tempo em segundos para seguir a linha antes de retorno

def imgmsg_to_numpy(img_msg):
    dtype = np.uint8
    img_np = np.frombuffer(img_msg.data, dtype=dtype)
    
    if img_msg.encoding == 'bgr8':
        img_np = img_np.reshape((img_msg.height, img_msg.width, 3))
    elif img_msg.encoding == 'rgb8':
        img_np = img_np.reshape((img_msg.height, img_msg.width, 3))
        img_np = cv2.cvtColor(img_np, cv2.COLOR_RGB2BGR)
    else:
        raise NotImplementedError(f"Tipo de codificação {img_msg.encoding} não implementado")
    
    return img_np

def numpy_to_imgmsg(np_img, encoding='bgr8'):
    img_msg = Image()
    img_msg.height = np_img.shape[0]
    img_msg.width = np_img.shape[1]
    img_msg.encoding = encoding
    img_msg.is_bigendian = 0
    img_msg.step = np_img.shape[1] * 3
    img_msg.data = np_img.tobytes()
    return img_msg

class LineFollower:
    def __init__(self, turn_side, turn_at_intersection, lost_line_turn, side_surpass, intersection_count_delay, depth_analysis_zones):
        self.stopped = False
        # Inicialização existente
        
        self.turn_side = turn_side
        self.turn_at_intersection = turn_at_intersection
        self.lost_line_turn = lost_line_turn
        self.original_lost_line_turn = lost_line_turn  
        self.side_surpass = side_surpass
        
        self.left_limit = 170
        self.right_limit = 470 
        self.intersection_count = 0
        self.left_persistence = 0
        self.right_persistence = 0
        self.last_known_line_position = None
        self.search_mode = False
        self.intersection_left_count = 0
        self.intersection_right_count = 0
        self.obstacle_detected = False
        self.lado = None
        self.avoiding_obstacle = False
        self.found_intersection = False
        self.desviar_esquerda = False
        self.desviar_direita = False

        self.ultrasound_front = float('inf')
        self.ultrasound_back = float('inf')
        self.ultrasound_front_buffer = []
        self.ultrasound_back_buffer = []
        self.buffer_size = 5 
        self.min_valid_count = 3
        self.desvio = 0

        self.flag_turn_after_avoid = 0
        
        # Adiciona novos atributos de análise de profundidade
        self.depth_analysis_zones = depth_analysis_zones  # Exemplo: [1, 1, 0]
        self.depth_persistence_count = [0, 0, 0]  # Contador de persistência para cada ponto de análise
        self.depth_threshold = 0.20  # Limite de distância em metros (20 cm)
        self.pixels_to_analyze = [(180, 240), (320, 240), (480, 240)]  # Posição dos três pontos -> MUDAR

        # Controle de tempo e estado
        self.following_start_time = None
        self.angular_movement_started = False
        self.timed_rotation_ready = False

                # Tempo de interseção
        self.intersection_count_delay = intersection_count_delay
        self.start_time = time.time()

        self.image_sub = rospy.Subscriber("/usb_cam/image_raw", Image, self.image_callback)
        self.depth_sub = rospy.Subscriber("/camera/depth/image_rect_raw", Image, self.depth_callback)
        self.move_time_pub = rospy.Publisher("/move_time", String, queue_size=10)
        self.cmd_vel_pub = rospy.Publisher('cmd_vel', Twist, queue_size=1)
        self.mask_pub = rospy.Publisher("/mask_image", Image, queue_size=1)
        self.ultrasound_right_sub = rospy.Subscriber("ultrasound_sensor_front", Float32, self.ultrasound_front_callback)
        self.ultrasound_left_sub = rospy.Subscriber("ultrasound_sensor_rear", Float32, self.ultrasound_back_callback)

    def is_condition_met(self, buffer, threshold):
        """
        Verifica se um número suficiente de leituras no buffer atendem ao limite especificado.
        """
        valid_count = sum(1 for value in buffer if value <= threshold)
        return valid_count >= self.min_valid_count

    def define_vertical_rois(self, image_width=640, margin=65):
        """
        Define faixas verticais de análise ao longo de todo o eixo y.
        :param image_width: Largura da imagem.
        :param margin: Margem ao redor de cada ponto no eixo x.
        :return: Lista de ROIs [(x_start, x_end)].
        """
        pixels_to_analyze = [(130, 240), (320, 240), (550, 240)]  # Pontos de análise
        rois = []

        for x, _ in pixels_to_analyze:
            x_start = max(0, x - 2*margin)
            x_end = min(image_width, x + 2*margin)
            rois.append((x_start, x_end))

        return rois

    def analyze_vertical_rois(self, depth_array, rois):
        """
        Analisa as profundidades nas faixas verticais definidas.
        :param depth_array: Array de profundidade.
        :param rois: Lista de faixas verticais [(x_start, x_end)].
        :return: Lista de médias de profundidade para cada faixa.
        """
        height, width = depth_array.shape
        results = []

        for x_start, x_end in rois:
            # Extraindo a faixa vertical
            vertical_strip = depth_array[:, x_start:x_end]

            # Calculando a profundidade média da faixa
            if vertical_strip.size > 0:  # Evita problemas com faixas vazias
                mean_depth = np.mean(vertical_strip) / 1000.0  # Converte para metros
            else:
                mean_depth = float('inf')  # Marca como muito distante

            results.append(mean_depth)

        return results

    
    def is_condition_met_back(self, buffer, threshold):
        """
        Verifica se um número suficiente de leituras no buffer atendem ao limite especificado.
        """
        valid_count = sum(1 for value in buffer if value >= threshold)
        return valid_count >= self.min_valid_count

    def ultrasound_front_callback(self, data):
        if not self.stopped:
            # Adicionar nova leitura ao buffer
            distance = data.data / 100.0  # Converte para metros
            if len(self.ultrasound_front_buffer) >= self.buffer_size:
                self.ultrasound_front_buffer.pop(0)  # Remove o valor mais antigo
            self.ultrasound_front_buffer.append(distance)

    def ultrasound_back_callback(self, data):
        if not self.stopped:
            # Adicionar nova leitura ao buffer
            distance = data.data / 100.0  # Converte para metros
            if len(self.ultrasound_back_buffer) >= self.buffer_size:
                self.ultrasound_back_buffer.pop(0)  # Remove o valor mais antigo
            self.ultrasound_back_buffer.append(distance)

    def depth_callback(self, data):
        if not self.stopped and not self.avoiding_obstacle and self.desvio == 0:
            try:
                # Converte a mensagem Image para um array NumPy
                depth_array = np.frombuffer(data.data, dtype=np.uint16).reshape(data.height, data.width)

                # Define as faixas verticais de análise
                rois = self.define_vertical_rois()

                # Analisa cada faixa e obtém as médias de profundidade
                depth_means = self.analyze_vertical_rois(depth_array, rois)

                # Processa cada faixa para verificar obstáculos com contagem de persistência
                for i, mean_depth in enumerate(depth_means):
                    if self.depth_analysis_zones[i] == 0:
                        continue  # Ignora zonas desativadas
                    rospy.loginfo(f"Distância na faixa {i} = {mean_depth}")
                    if mean_depth < self.depth_threshold:
                        self.depth_persistence_count[i] += 1
                    else:
                        self.depth_persistence_count[i] = 0

                    # Verifica se a persistência atingiu o limite
                    if self.depth_persistence_count[i] >= 6 and not self.obstacle_detected:
                        rospy.loginfo(f"Obstáculo detectado na faixa {i} após 6 leituras consecutivas. Iniciando desvio.")
                        self.obstacle_detected = True
                        rospy.sleep(1.0)
                        self.desvio += 1
                        self.handle_obstacle_rotation(i)
                        self.depth_persistence_count[i] = 0  # Reinicia a contagem para a faixa atual
                        break  # Evita múltiplos desvios simultâneos

            except Exception as e:
                rospy.logerr(f"Erro ao processar a imagem de profundidade: {e}")

    def image_callback(self, data):
        if self.stopped or self.obstacle_detected:
            return

        try:
            cv_image = imgmsg_to_numpy(data)
            self.process_image(cv_image)
        except Exception as e:
            rospy.logerr("Erro ao converter imagem ROS para OpenCV: %s", e)

    def process_image(self, current_frame):
        # Aplicar a máscara corretamente
        masked_frame = create_mask(current_frame, self.left_limit, self.right_limit)
        rospy.loginfo(f"Contagem de detecção de objetos - Esquerda: {self.depth_persistence_count[0]}, "
                  f"Centro: {self.depth_persistence_count[1]}, Direita: {self.depth_persistence_count[2]}")
        
        hsv_image = cv2.cvtColor(masked_frame, cv2.COLOR_BGR2HSV)
        lower_blue = np.array([89, 59, 1])  
        upper_blue = np.array([124, 255, 133])
        blue_mask = cv2.inRange(hsv_image, lower_blue, upper_blue)

        line = self.get_contour_data(blue_mask)
        cmd_vel = Twist()

        if line:
            self.search_mode = False
            self.last_known_line_position = line
            x, y = line['x'], line['y']
            _, width, _ = masked_frame.shape
            error = x - width // 2

            if self.obstacle_detected:
                pass
            else:
                cmd_vel.linear.x = LINEAR_SPEED
                cmd_vel.linear.y = float(error) * -KP_BASE

                #rospy.loginfo(f"Linha detectada - Velocidade Angular: {cmd_vel.linear.y:.2f}")
                rospy.loginfo(f"Interseções detectadas - Esquerda: {self.intersection_left_count}, Direita: {self.intersection_right_count}")

                cv2.circle(masked_frame, (x, y), 5, (0, 255, 0), -1)
                self.check_for_intersections(blue_mask, masked_frame, cmd_vel)
                self.cmd_vel_pub.publish(cmd_vel)
        else:
            
            self.search_mode = True
            cmd_vel.linear.x = 0.0
            if self.lost_line_turn == 0:
                cmd_vel.linear.x = 0.2
                cmd_vel.linear.y = 0
                #rospy.loginfo("Linha não detectada - Andando para a FRENTE no modo de busca")
            elif self.lost_line_turn == 1:
                cmd_vel.angular.z = 0.8
                #rospy.loginfo("Linha não detectada - Virando para ESQUERDA no modo de busca")
            elif self.lost_line_turn == 2:
                cmd_vel.angular.z = -0.8
                #rospy.loginfo("Linha não detectada - Virando para DIREITA no modo de busca")
            self.cmd_vel_pub.publish(cmd_vel)
            #rospy.loginfo(f"Velocidade Angular no Modo de Busca: {cmd_vel.linear.y:.2f}")
            #rospy.loginfo(f"Interseções detectadas - Esquerda: {self.intersection_left_count}, Direita: {self.intersection_right_count}")

        # try:
        #     mask_image_msg = numpy_to_imgmsg(masked_frame, encoding="bgr8")
        #     self.mask_pub.publish(mask_image_msg)

        #     image_save_path = "/home/rmajetson/saved_images/processed_image.jpg"
        #     cv2.imwrite(image_save_path, masked_frame)
        # except Exception as e:
        #     rospy.logerr("Falha ao converter e publicar a imagem da máscara: %s", e)

    def handle_obstacle_rotation(self, obstacle_position):
        global goal_value
        # Define direção do desvio com base no ponto onde o obstáculo foi detectado
        if obstacle_position == 0:
            rospy.loginfo("Desviando para a DIREITA devido a obstáculo na esquerda.")
            comando = "direita,3.0"
            self.lado = 1
        elif obstacle_position == 2:  
            rospy.loginfo("Desviando para a ESQUERDA devido a obstáculo na direita.")
            comando = "esquerda,3.0"
            self.lado = 2

        self.move_time_pub.publish(comando)
        rospy.sleep(ANGULAR_Z_DURATION + 1.5)

        self.move_time_pub.publish("frente,5.5")
        rospy.sleep(6.5)

        if ((goal_value == 13 or goal_value == 14) and self.is_condition_met_back(self.ultrasound_back_buffer, 1.57)):
            rospy.loginfo("Somei uma intersecção aqui pelo ultrassonico de tras")
            self.intersection_left_count += 1

        ######Fazer a verificação do seg_12()

        self.angular_movement_started = True
        self.avoiding_obstacle = True  # Ativar modo de desvio
        self.handle_timed_return_rotation()

    def handle_timed_return_rotation(self):
        global goal_value  # Para acessar o valor do objetivo globalmente

        if self.lado == 1:  
            rospy.loginfo("Voltando para a ESQUERDA .")
            comando = "esquerda,3.0"
        elif self.lado == 2:  
            rospy.loginfo("Voltando para a DIREITA .")
            comando = "direita,3.0"

        # Publica o comando de desvio
        self.move_time_pub.publish(comando)
        rospy.sleep(ANGULAR_Z_DURATION + 1.5)

        # Analisar os buffers para decidir a ação
        front_condition_met = self.is_condition_met(self.ultrasound_front_buffer, 2.15)
        back_condition_met = self.is_condition_met(self.ultrasound_back_buffer, 1.55)

        # Ações baseadas no goal e leituras dos sensores
        if front_condition_met:
            rospy.loginfo("Condição atendida no sensor frontal após análise do buffer.")
            if goal_value == 13:
                if self.is_condition_met(self.ultrasound_front_buffer, 1.62):
                    rospy.loginfo("Caso 13(a): Condição de proximidade extrema atendida. Girando e finalizando.")
                    self.flag_turn_after_avoid = 1
                    rospy.sleep(0.5)
                else:
                    rospy.loginfo("Caso 13(a): Condição geral atendida. Finalizando.")
                    rospy.sleep(0.5)
                self.stopped = True

            elif goal_value == 14:
                rospy.loginfo("Caso 14: Condição atendida. Virando e finalizando.")
                self.stopped = True

            elif goal_value == 15:
                if self.is_condition_met(self.ultrasound_front_buffer, 0.35):
                    rospy.loginfo("Caso 15: Condição de proximidade extrema atendida. Giro imediato para a direita.")
                    self.flag_turn_after_avoid = 1
                    rospy.sleep(0.5)
                self.stopped = True

            elif goal_value in [51, 41, 31, 21]:
                if self.is_condition_met(self.ultrasound_front_buffer, 1.0):
                    rospy.loginfo("Casos 51/41/31/21: Condição atendida. Finalizando.")
                    rospy.sleep(0.5)
                    if self.is_condition_met(self.ultrasound_front_buffer, 0.5):
                        self.flag_turn_after_avoid = 1
                    self.stopped = True

            # elif goal_value == 12:
            #     rospy.loginfo("Goal 12: Continuando com lógica personalizada.")
            #     # Lógica específica para o goal 12, se aplicável

            elif goal_value == 26:
                rospy.loginfo("Goal 26: Executando lógica personalizada para retorno.")
                # Adicionar lógica específica para o goal 26, se aplicável

            elif goal_value == 36:
                if self.is_condition_met(self.ultrasound_front_buffer, 1.0):
                    rospy.loginfo("Goal 36: Retorno seguro detectado. Finalizando.")
                    rospy.sleep(0.5)
                    self.stopped = True

            elif goal_value == 46:
                rospy.loginfo("Goal 46: Retorno seguro detectado. Concluindo sequência.")
                # Adicionar lógica específica para o goal 46, se aplicável
                self.stopped = True

            elif goal_value == 56:
                rospy.loginfo("Goal 56: Finalizando a sequência de retorno.")
                self.stopped = True

        elif back_condition_met:
            rospy.loginfo("Condição atendida no sensor traseiro após análise do buffer.")
            # Lógica para lidar com o sensor traseiro, se aplicável

        # Reinicia parâmetros do seguidor
        self.lost_line_turn = self.original_lost_line_turn
        self.angular_movement_started = False
        self.following_start_time = None
        self.timed_rotation_ready = False
        self.desviar_direita = False
        self.desviar_esquerda = False
        self.obstacle_detected = False
        self.avoiding_obstacle = False
            
    def check_for_intersections(self, mask, frame, cmd_vel):
        # global goal_value

        h, w = mask.shape

        # if ((goal_value == 14 or goal_value == 13) and self.is_condition_met(self.ultrasound_front_buffer, 1.6) and self.desvio == 1):
        #     rospy.loginfo("Achei a segunda intersecção por meio do ultrassonico")
        #     self.intersection_left_count += 1
        #     if(self.intersection_left_count >= 2):
        #         self.stopped = True
        #         return
        
        # if self.intersection_left_count >= self.turn_at_intersection and self.turn_side == 1:
        #     self.stopped == True
        #     return
        
        left_region = mask[:, self.left_limit:int(self.left_limit + (w * DETECTION_REGION_PERCENTAGE))]
        right_region = mask[:, int(self.right_limit - (w * DETECTION_REGION_PERCENTAGE)):self.right_limit]

        left_lower_half = left_region[int(h / 2):, :]
        right_lower_half = right_region[int(h / 2):, :]

        cv2.rectangle(frame, (self.left_limit, int(h / 2)), 
                    (int(self.left_limit + (w * DETECTION_REGION_PERCENTAGE)), h), (255, 0, 0), 2)
        cv2.rectangle(frame, (int(self.right_limit - (w * DETECTION_REGION_PERCENTAGE)), int(h / 2)), 
                    (self.right_limit, h), (0, 0, 255), 2)

        left_pixels = cv2.countNonZero(left_lower_half)
        right_pixels = cv2.countNonZero(right_lower_half)
        
        total_left_pixels = left_lower_half.shape[0] * left_lower_half.shape[1]
        total_right_pixels = right_lower_half.shape[0] * right_lower_half.shape[1]

        left_proportion = left_pixels / total_left_pixels
        right_proportion = right_pixels / total_right_pixels

        if left_proportion > MIN_LINE_PROPORTION:
            self.left_persistence += 1
        else:
            self.left_persistence = 0

        if self.left_persistence >= MIN_PERSISTENCE_FRAMES:
            if not self.left_detected:
                self.intersection_left_count += 1
                #rospy.loginfo("Interseção detectada à esquerda!")
                self.left_detected = True
                self.intersection_count += 1

                if self.intersection_left_count == self.turn_at_intersection and self.turn_side == 1:
                    cmd_vel.linear.x = 0.0
                    cmd_vel.angular.z = 0.0
                    self.cmd_vel_pub.publish(cmd_vel)
                    #rospy.loginfo("Virando à esquerda e parando.")
                    self.found_intersection = True
                    self.stopped = True
        else:
            self.left_detected = False

        if right_proportion > MIN_LINE_PROPORTION:
            self.right_persistence += 1
        else:
            self.right_persistence = 0

        if self.right_persistence >= MIN_PERSISTENCE_FRAMES:
            if not self.right_detected:
                self.intersection_right_count += 1
                #rospy.loginfo("Interseção detectada à direita!")
                self.right_detected = True
                self.intersection_count += 1

                if self.intersection_right_count == self.turn_at_intersection and self.turn_side == 2:
                    cmd_vel.linear.x = 0.0
                    cmd_vel.angular.z = 0.0
                    self.cmd_vel_pub.publish(cmd_vel)
                    #rospy.loginfo("Virando à direita e parando.")
                    self.found_intersection = True
                    self.stopped = True
        else:
            self.right_detected = False

    def get_contour_data(self, mask):
        contours, _ = cv2.findContours(mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if contours:
            largest_contour = max(contours, key=cv2.contourArea)
            area = cv2.contourArea(largest_contour)

            if area > MIN_AREA_TRACK:
                M = cv2.moments(largest_contour)
                cx = int(M['m10'] / M['m00'])
                cy = int(M['m01'] / M['m00'])
                #rospy.loginfo(f"Contorno detectado - Área: {area}, Centro X: {cx}, Y: {cy}")
                return {'x': cx, 'y': cy}
        #rospy.loginfo("Nenhum contorno suficientemente grande detectado.")
        return None

    def start(self):
        rate = rospy.Rate(50)
        feedback_scheduler = 0.0
        #rospy.loginfo("Iniciando seguidor de linha.")
        while not rospy.is_shutdown() and not self.stopped:
            rate.sleep()
        
        return self.flag_turn_after_avoid

def create_mask(image, left_limit, right_limit):
    h, w = image.shape[:2]
    left_mask_points = np.array([(0, 0), (left_limit, 0), (left_limit, h), (0, h)])
    right_mask_points = np.array([(right_limit, 0), (w, 0), (w, h), (right_limit, h)])
    
    mask = np.ones_like(image) * 255
    cv2.fillPoly(mask, [left_mask_points], (0, 0, 0))
    cv2.fillPoly(mask, [right_mask_points], (0, 0, 0))
    
    masked_img = cv2.bitwise_and(image, mask)
    return masked_img


def seg_12():

 # #Giro inicial de 90°
    move_time_pub.publish("esquerda_90,2.4")
    rospy.sleep(3.0)
    move_time_pub.publish("esquerda,3.0")
    rospy.sleep(3.8)

#----------------------------------------------------------------------------------------------#

    turn_side = 1 
    turn_at_intersection = 1 
    lost_line_turn = 0 
    surpass_side = 1 
    time_delay = 3.0
    zonas_de_analise = [0,0,0]

    follower = LineFollower(turn_side, turn_at_intersection, lost_line_turn, surpass_side, time_delay,zonas_de_analise)

    #rospy.loginfo("Iniciando o seguidor de linha...")
    follower.start()

    #rospy.loginfo("Seguidor de linha finalizado. Executando a curva para a esquerda.")

    move_time_pub.publish("frente,1.9")
    rospy.sleep(2.5)
    move_time_pub.publish("esquerda_90,2.3")
    rospy.sleep(3.0)

    #Pub_feedback
    for _ in range(6):
        feedback_pub.publish(1)


def seg_teste():
    turn_side = 1 
    turn_at_intersection = 2
    lost_line_turn = 0  
    surpass_side = 1  
    time_delay = 1.0
    zonas_de_analise = [0,0,0]

    follower = LineFollower(turn_side, turn_at_intersection, lost_line_turn, surpass_side, time_delay, zonas_de_analise)

    #rospy.loginfo("Iniciando o seguidor de linha...")
    follower.start()
    #rospy.loginfo("Seguidor de linha finalizado. Executando a curva para a esquerda.")

def seg_13():

    # #Giro inicial de 90°
    move_time_pub.publish("esquerda_90,2.5")
    rospy.sleep(3.0)
    move_time_pub.publish("esquerda,3.6")
    rospy.sleep(4.3)

#----------------------------------------------------------------------------------------------#
    turn_side = 1 
    turn_at_intersection = 2 
    lost_line_turn = 0 
    surpass_side = 1 
    time_delay = 3.0
    zonas_de_analise = [0,0,0]

    follower = LineFollower(turn_side, turn_at_intersection, lost_line_turn, surpass_side, time_delay,zonas_de_analise)

    #rospy.loginfo("Iniciando o seguidor de linha...")
    flag_turn = follower.start()

    #rospy.loginfo("Seguidor de linha finalizado. Executando a curva para a esquerda.")

    if flag_turn != 1:
        move_time_pub.publish("frente,2.2")
        rospy.sleep(2.5)
    move_time_pub.publish("esquerda_90,2.3")
    rospy.sleep(5.0)
#----------------------------------------------------------------------------------------------#
    turn_side = 2  
    turn_at_intersection = 1 
    lost_line_turn = 2  
    surpass_side = 1 
    time_delay = 5.5
    zonas_de_analise = [0,0,0]
    follower2 = LineFollower(turn_side, turn_at_intersection, lost_line_turn, surpass_side, time_delay, zonas_de_analise)

    #rospy.loginfo("Iniciando o seguidor de linha...")
    follower2.start()
    #rospy.loginfo("Seguidor de linha finalizado. Executando a curva para a direita...")
    move_time_pub.publish("direita_90,2.2")
    rospy.sleep(2.5)
    move_time_pub.publish("frente,1.1")
    rospy.sleep(1.8)

    #Pub_feedback
    for _ in range(6):
        feedback_pub.publish(1)

def seg_14():

    move_time_pub.publish("esquerda_90,2.4")
    rospy.sleep(3.0)
    move_time_pub.publish("esquerda,3.3")
    rospy.sleep(4.5)
#----------------------------------------------------------------------------------------------#
    
    turn_side = 1  
    turn_at_intersection = 2 
    lost_line_turn = 1
    surpass_side = 1  
    time_delay = 3.5
    zonas_de_analise = [0,0,0]

    follower = LineFollower(turn_side, turn_at_intersection, lost_line_turn, surpass_side, time_delay, zonas_de_analise)
    #rospy.loginfo("Iniciando o seguidor de linha...")
    follower.start()
    #rospy.loginfo("Seguidor de linha finalizado. Executando a curva para a esquerda.")

    move_time_pub.publish("tras,2.3")
    rospy.sleep(3.0)
    move_time_pub.publish("direita_90,2.4")
    rospy.sleep(4)

#----------------------------------------------------------------------------------------------#

    move_time_pub.publish("frente,2.4")
    rospy.sleep(3.5)
    
    #Pub_feedback
    for _ in range(6):
        feedback_pub.publish(1)

def seg_15():

    move_time_pub.publish("esquerda_90,2.4")
    rospy.sleep(3.5)
    move_time_pub.publish("esquerda,3.5")
    rospy.sleep(5.0)

#----------------------------------------------------------------------------------------------#
    turn_side = 2  
    turn_at_intersection = 1
    lost_line_turn = 2 
    surpass_side = 1  
    time_delay = 7.0
    zonas_de_analise = [0,0,0]

    follower = LineFollower(turn_side, turn_at_intersection, lost_line_turn, surpass_side, time_delay, zonas_de_analise)
    flag_turn = follower.start()

    if flag_turn != 1:
        move_time_pub.publish("frente,1.7")
        rospy.sleep(2.4)
    move_time_pub.publish("direita_90,2.2")
    rospy.sleep(4.0)

    #Pub_feedback
    for _ in range(6):
        feedback_pub.publish(1)


def seg_16():
    # #Giro inicial de 90°
    move_time_pub.publish("esquerda_90,2.4")
    rospy.sleep(3.0)
    move_time_pub.publish("esquerda,3.0")
    rospy.sleep(3.8)

#----------------------------------------------------------------------------------------------#
    turn_side = 2 
    turn_at_intersection = 1 
    lost_line_turn = 1 
    surpass_side = 1 
    time_delay = 6.0
    zonas_de_analise = [0,0,0]

    follower = LineFollower(turn_side, turn_at_intersection, lost_line_turn, surpass_side, time_delay,zonas_de_analise)
    follower.start()

    move_time_pub.publish("frente,1.4")
    rospy.sleep(3.0)
    move_time_pub.publish("esquerda_90,2.2")
    rospy.sleep(3.0)
    move_time_pub.publish("frente,7.7")
    rospy.sleep(10.5)

    #Pub_feedback
    for _ in range(6):
        feedback_pub.publish(1)

def seg_51():

    move_time_pub.publish("tras,1.5")
    rospy.sleep(3.0)
    move_time_pub.publish("direita_90,2.4")
    rospy.sleep(3.0)
    move_time_pub.publish("direita,3.0")
    rospy.sleep(3.0)

#----------------------------------------------------------------------------------------------#
    turn_side = 1  
    turn_at_intersection = 1
    lost_line_turn = 2 
    surpass_side = 1  
    time_delay = 5.0
    zonas_de_analise = [0,0,0]

    follower = LineFollower(turn_side, turn_at_intersection, lost_line_turn, surpass_side, time_delay, zonas_de_analise)
    #rospy.loginfo("Iniciando o seguidor de linha...")
    follower.start()
    #rospy.loginfo("Seguidor de linha finalizado. Executando a curva para a direita.")

    move_time_pub.publish("frente,3.3")
    rospy.sleep(3.8)
    move_time_pub.publish("esquerda_90,2.2")
    rospy.sleep(4.0)

    #Pub_feedback
    for _ in range(6):
        feedback_pub.publish(1)

def seg_26():

    move_time_pub.publish("direita_90,4.4")
    rospy.sleep(5.5)

#----------------------------------------------------------------------------------------------#

    turn_side = 2  
    turn_at_intersection = 1 
    lost_line_turn = 2
    surpass_side = 1 
    time_delay = 3.5
    zonas_de_analise = [0,0,0]

    follower2 = LineFollower(turn_side, turn_at_intersection, lost_line_turn, surpass_side, time_delay, zonas_de_analise)
    #rospy.loginfo("Iniciando o seguidor de linha...")
    follower2.start()

    move_time_pub.publish("frente,2.7")
    rospy.sleep(3.5)
    move_time_pub.publish("esquerda_90,2.4")
    rospy.sleep(3.0)

#----------------------------------------------------------------------------------------------#
    
    turn_side = 2  
    turn_at_intersection = 1 
    lost_line_turn = 0  
    surpass_side = 1 
    time_delay = 2.0
    zonas_de_analise = [0,0,0]

    follower2 = LineFollower(turn_side, turn_at_intersection, lost_line_turn, surpass_side, time_delay, zonas_de_analise) 
    #rospy.loginfo("Iniciando o seguidor de linha...")
    follower2.start()

    move_time_pub.publish("frente,1.4")
    rospy.sleep(3.0)
    move_time_pub.publish("esquerda_90,2.2")
    rospy.sleep(3.0)
    move_time_pub.publish("frente,7.7")
    rospy.sleep(10.5)

    #Pub_feedback
    for _ in range(6):
        feedback_pub.publish(1)



def seg_21():
    move_time_pub.publish("direita_90,4.4")
    rospy.sleep(5.5)

#----------------------------------------------------------------------------------------------#

    turn_side = 2  
    turn_at_intersection = 1 
    lost_line_turn = 2
    surpass_side = 1 
    time_delay = 3.5
    zonas_de_analise = [0,0,0]

    follower2 = LineFollower(turn_side, turn_at_intersection, lost_line_turn, surpass_side, time_delay, zonas_de_analise)
    #rospy.loginfo("Iniciando o seguidor de linha...")
    follower2.start()

    move_time_pub.publish("frente,4.0")
    rospy.sleep(5.5)
    move_time_pub.publish("direita_90,2.2")
    rospy.sleep(3.0)

#----------------------------------------------------------------------------------------------#

    turn_side = 1 
    turn_at_intersection = 1 
    lost_line_turn = 2
    surpass_side = 1 
    time_delay = 3.5
    zonas_de_analise = [0,0,0]

    follower2 = LineFollower(turn_side, turn_at_intersection, lost_line_turn, surpass_side, time_delay, zonas_de_analise)
    #rospy.loginfo("Iniciando o seguidor de linha...")
    flag_turn = follower2.start()

    if flag_turn != 1:
        move_time_pub.publish("frente,2,9")
        rospy.sleep(3.5)
    move_time_pub.publish("esquerda_90,2.2")
    rospy.sleep(3.0)

    #Pub_feedback
    for _ in range(6):
        feedback_pub.publish(1)


def seg_41():

    move_time_pub.publish("direita_90,2.1")
    rospy.sleep(3.5)
    move_time_pub.publish("direita,3.8")
    rospy.sleep(5.2)

#----------------------------------------------------------------------------------------------#

    turn_side = 1  
    turn_at_intersection = 1 
    lost_line_turn = 2
    surpass_side = 1 
    time_delay = 6.5
    zonas_de_analise = [0,0,0]

    follower2 = LineFollower(turn_side, turn_at_intersection, lost_line_turn, surpass_side, time_delay, zonas_de_analise)
    #rospy.loginfo("Iniciando o seguidor de linha...")
    flag_turn = follower2.start()

    if flag_turn != 1:
        move_time_pub.publish("frente,3.3")
        rospy.sleep(3.8)
    move_time_pub.publish("esquerda_90,2.1")
    rospy.sleep(3.0)

    #Pub_feedback
    for _ in range(6):
        feedback_pub.publish(1)

def seg_31():

    move_time_pub.publish("direita,1.5")
    rospy.sleep(2.0)
    move_time_pub.publish("tras,1.3")
    rospy.sleep(1.6)
    move_time_pub.publish("direita_90,2.4")
    rospy.sleep(3.0)

#----------------------------------------------------------------------------------------------#
    turn_side = 1  
    turn_at_intersection = 1  
    lost_line_turn = 2 
    surpass_side = 1  
    time_delay = 3.0
    zonas_de_analise = [0,0,0]

    follower = LineFollower(turn_side, turn_at_intersection, lost_line_turn, surpass_side, time_delay, zonas_de_analise)
    #rospy.loginfo("Iniciando o seguidor de linha...")
    flag_turn = follower.start()

    if flag_turn != 1:
        move_time_pub.publish("frente,2.75")
        rospy.sleep(3.5)
    move_time_pub.publish("direita_90,2.1")
    rospy.sleep(2.5)

#----------------------------------------------------------------------------------------------#

    turn_side = 1 
    turn_at_intersection = 1 
    lost_line_turn = 0  
    surpass_side = 1  
    time_delay = 3.0
    zonas_de_analise = [0,0,0]

    follower2 = LineFollower(turn_side, turn_at_intersection, lost_line_turn, surpass_side, time_delay, zonas_de_analise)
    #rospy.loginfo("Iniciando o seguidor de linha...")
    flag_turn = follower2.start()

    if flag_turn != 1:
        move_time_pub.publish("frente,3.5")
        rospy.sleep(4.0)
    move_time_pub.publish("esquerda_90,2.2")
    rospy.sleep(3.0)

    #Pub_feedback
    for _ in range(6):
        feedback_pub.publish(1)
    

def seg_36():
    
    move_time_pub.publish("direita,1.5")
    rospy.sleep(2.0)
    move_time_pub.publish("tras,1.3")
    rospy.sleep(1.6)
    move_time_pub.publish("direita_90,2.4")
    rospy.sleep(3.0)

#----------------------------------------------------------------------------------------------#
    turn_side = 1 
    turn_at_intersection = 1  
    lost_line_turn = 1 
    surpass_side = 1 
    time_delay = 4.0
    zonas_de_analise = [0,0,0]

    follower = LineFollower(turn_side, turn_at_intersection, lost_line_turn, surpass_side, time_delay, zonas_de_analise)
    #rospy.loginfo("Iniciando o seguidor de linha...")
    follower.start()
    #rospy.loginfo("Seguidor de linha finalizado. Executando a curva para a esquerda.")

    move_time_pub.publish("frente,2.3")
    rospy.sleep(3.0)
    move_time_pub.publish("esquerda_90,2.2")
    rospy.sleep(3.0)

#----------------------------------------------------------------------------------------------#

    turn_side = 2  
    turn_at_intersection = 1 
    lost_line_turn = 0  
    surpass_side = 1 
    time_delay = 2.0
    zonas_de_analise = [0,0,0]

    follower2 = LineFollower(turn_side, turn_at_intersection, lost_line_turn, surpass_side, time_delay, zonas_de_analise) 
    #rospy.loginfo("Iniciando o seguidor de linha...")
    follower2.start()

    move_time_pub.publish("frente,1.4")
    rospy.sleep(3.0)
    move_time_pub.publish("esquerda_90,2.2")
    rospy.sleep(3.0)
    move_time_pub.publish("frente,7.7")
    rospy.sleep(10.5)

    #Pub_feedback
    for _ in range(6):
        feedback_pub.publish(1)

def seg_46():

    move_time_pub.publish("tras,2.7")
    rospy.sleep(5.5)
    move_time_pub.publish("esquerda_90,2.6")
    rospy.sleep(3.0)
#----------------------------------------------------------------------------------------------#

    turn_side = 2  
    turn_at_intersection = 1 
    lost_line_turn = 0  
    surpass_side = 1 
    time_delay = 2.0
    zonas_de_analise = [0,0,0]

    follower2 = LineFollower(turn_side, turn_at_intersection, lost_line_turn, surpass_side, time_delay, zonas_de_analise) 
    #rospy.loginfo("Iniciando o seguidor de linha...")
    follower2.start()

    move_time_pub.publish("frente,1.4")
    rospy.sleep(3.0)
    move_time_pub.publish("esquerda_90,2.2")
    rospy.sleep(3.0)
    move_time_pub.publish("frente,7.9")
    rospy.sleep(10.5)

    #Pub_feedback
    for _ in range(6):
        feedback_pub.publish(1)
    
def seg_56():

    move_time_pub.publish("direita_90,2.4")
    rospy.sleep(3.0)
    move_time_pub.publish("tras,1.0")
    rospy.sleep(1.5)
    move_time_pub.publish("direita,12.0")
    rospy.sleep(13.5)

    #Pub_feedback
    for _ in range(6):
        feedback_pub.publish(1)


def goal_callback(msg):
    global goal_value
    """
    Callback executado quando uma nova mensagem é recebida no tópico "goal_line_follower".
    Dependendo do valor da mensagem, a função correspondente é chamada.
    """
    goal_value = msg.data
    #rospy.loginfo(f"Recebido novo goal: {goal_value}")

    if goal_value == 12:
        #rospy.loginfo("Executando o segmento 12.")
        seg_12()
    elif goal_value == 21:
        #rospy.loginfo("Executando o segmento 21.")
        seg_21()
    elif goal_value == 26:
        #rospy.loginfo("Executando o segmento 26 (seg_26).")
        seg_26()
    elif goal_value == 13:
        #rospy.loginfo("Executando o segmento 13.")
        seg_13()
    elif goal_value == 14:
        #rospy.loginfo("Executando o segmento 14.")
        seg_14()
    elif goal_value == 15:
        #rospy.loginfo("Executando o segmento 15.")
        seg_15()
    elif goal_value == 16:
        seg_16()
    elif goal_value == 51:
        #rospy.loginfo("Executando o segmento 51.")
        seg_51()
    elif goal_value == 41:
        #rospy.loginfo("Executando o segmento 41 (seg_41).")
        seg_41()
    elif goal_value == 31:
        seg_31()
        #rospy.loginfo("Executando o segmento 31 (seg_31).")
    elif goal_value == 36:
        seg_36()
        #rospy.loginfo("Executando o segmento 36 (seg_36).")
    elif goal_value == 46:
        seg_46()
    elif goal_value == 56:
        seg_56()
        #rospy.loginfo("Executando o segmento 46 (seg_46).")
    elif goal_value == 99:
        seg_teste()
        #rospy.loginfo("Executando o segmento de teste")
    else:
        rospy.loginfo("Goal desconhecido. Nenhuma ação executada.")
    

def listener():
    global feedback_pub
    global move_time_pub
    """
    Função principal que inicializa o nó e se inscreve no tópico "goal_line_follower".
    """
    rospy.init_node('goal_line_follower_listener', anonymous=True)
    
    # Inscreve-se no tópico "goal_line_follower", esperando por valores inteiros
    rospy.Subscriber('goal_line_follower', Int32, goal_callback)
    feedback_pub = rospy.Publisher('line_follower_feedback', Int32, queue_size=10)
    move_time_pub = rospy.Publisher("/move_time", String, queue_size=10)

    # Mantém o nó em execução até que seja encerrado
    rospy.loginfo("Aguardando novos goals no tópico 'goal_line_follower'...")
    rospy.spin()

if __name__ == '__main__':
    try:
        listener()
    except rospy.ROSInterruptException:
        rospy.loginfo("Node encerrado.")

