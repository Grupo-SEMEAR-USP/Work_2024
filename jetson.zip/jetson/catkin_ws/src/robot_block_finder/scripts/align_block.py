#!/usr/bin/env python3

import rospy
from apriltag_ros.msg import AprilTagDetectionArray
from geometry_msgs.msg import Twist
from std_msgs.msg import Int32, String

has_converged = False
search_active = False
alignment_pub = None
target_block_id = None

incorrect_detection_count = 0  # Contador de leituras incorretas
max_incorrect_detections = 8   # Número máximo de leituras incorretas permitidas
last_valid_position = None     # Armazena a última posição válida do bloco

def start_search_callback(msg):
    global search_active, has_converged, target_block_id, incorrect_detection_count, last_valid_position
    search_active = True
    has_converged = False
    target_block_id = int(msg.data)
    incorrect_detection_count = 0  # Reseta o contador ao iniciar uma nova busca
    last_valid_position = None  # Reseta a última posição válida
    rospy.loginfo(f"Buscando pelo bloco de ID {target_block_id} iniciado.")

def tag_detections_callback(data):
    global has_converged, search_active, alignment_pub, target_block_id, incorrect_detection_count, last_valid_position

    if not search_active:
        return

    if has_converged:
        return

    detected_target = False

    # Verifica as tags detectadas
    for detection in data.detections:
        tag_id = detection.id[0]
        if tag_id == target_block_id:
            detected_target = True  # Alvo detectado
            last_valid_position = detection.pose.pose.pose.position  # Atualiza a última posição válida

    # Se o bloco alvo não foi encontrado, incrementa o contador de leituras incorretas
    if not detected_target:
        incorrect_detection_count += 1
        rospy.loginfo(f"Bloco alvo não detectado. Leituras incorretas: {incorrect_detection_count}")
        
        # Se o número de leituras incorretas atingir o limite, desiste da busca
        if incorrect_detection_count >= max_incorrect_detections:
            rospy.loginfo("Bloco alvo não encontrado após múltiplas tentativas. Desistindo.")
            alignment_pub.publish(0)
            stop_robot()
            search_active = False
        elif last_valid_position:  # Se houver uma última posição válida, tenta alinhar-se com ela
            align_with_position(last_valid_position)
        return
    else:
        # Reseta o contador se o bloco alvo for encontrado
        incorrect_detection_count = 0
        if last_valid_position:  # Tenta alinhar-se usando a posição atualizada
            align_with_position(last_valid_position)

def align_with_position(position):
    global has_converged, alignment_pub, search_active
    cmd_vel = Twist()

    # Define o deslocamento da garra em relação ao centro da câmera
    offset_x = 0.0050260697861753125
    offset_y = 0.03122536780988897

    # Compensa o deslocamento da garra ao calcular as coordenadas de alinhamento
    adjusted_x = position.x - offset_x
    adjusted_y = position.y - offset_y

    # Prioridade para o alinhamento horizontal (eixo Y)
    if abs(adjusted_y) > 0.01:  
        cmd_vel.linear.x = -0.08 if adjusted_y > 0.01 else 0.08  # Ajusta para alinhar no eixo Y
        cmd_vel.angular.z = 0  # Não move no eixo X até que Y esteja alinhado

    # Alinhamento vertical (eixo X) somente quando o eixo Y estiver alinhado
    elif abs(adjusted_x) > 0.005:  
        cmd_vel.linear.x = 0  # Para a movimentação no eixo Y
        cmd_vel.angular.z = -0.08 if adjusted_x > 0.005 else 0.08  # Ajusta para alinhar no eixo X

    # Se o robô está alinhado em ambos os eixos
    else:
        cmd_vel.linear.x = 0
        cmd_vel.angular.z = 0
        if not has_converged:
            rospy.loginfo("Robô alinhado com o bloco.")
            send_found_signal()
            
            for b in range(5):
                alignment_pub.publish(1)
                rospy.sleep(0.1)

            has_converged = True  # Marca o robô como alinhado
            search_active = False
            target_block_id = None

    # Publica os comandos de movimento
    vel_pub.publish(cmd_vel)

def send_found_signal():
    global search_active
    rospy.loginfo("Bloco alinhado!")
    search_active = False

def stop_robot():
    cmd_vel = Twist()
    cmd_vel.linear.x = 0
    cmd_vel.angular.z = 0
    vel_pub.publish(cmd_vel)
    search_active = False

def main():
    global vel_pub, alignment_pub

    rospy.init_node('align_block', anonymous=True)

    vel_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
    alignment_pub = rospy.Publisher('/block_align/feedback', Int32, queue_size=10)
    rospy.Subscriber('/tag_detections', AprilTagDetectionArray, tag_detections_callback)
    rospy.Subscriber('/block_align', String, start_search_callback)

    rospy.spin()

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass